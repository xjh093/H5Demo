//
//  ViewController.h
//  H5Demo
//
//  Created by xuejinghao on 2018/7/17.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHBaseH5VC.h"

@interface ViewController : JHBaseH5VC


@end

