//
//  JHNavigationController.m
//  JHKit
//
//  Created by HaoCold on 2017/2/10.
//  Copyright © 2017年 HaoCold. All rights reserved.
//

#import "JHNavigationController.h"

@interface JHNavigationController()<UIGestureRecognizerDelegate>
@property (nonatomic,  strong) UIButton *backButton;
@end

@implementation JHNavigationController

- (void)viewDidLoad{
    [super viewDidLoad];
    
    // 导航条字体颜色
    [[UINavigationBar appearance] setTitleTextAttributes:
     @{NSForegroundColorAttributeName:[UIColor grayColor],
       NSFontAttributeName:[UIFont boldSystemFontOfSize:17]}];
    
    // 导航条背景颜色
    //[[UINavigationBar appearance] setBarTintColor:kMainColor];
    
    // 左滑返回
    __weak typeof(self) weakSelf = self;
    if ([self respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.interactivePopGestureRecognizer.delegate = weakSelf;
    }
    
}

#pragma mark - private

- (void)back
{
    if (_backDelegate && [_backDelegate respondsToSelector:@selector(didClickBackButton:)]) {
        [_backDelegate didClickBackButton:_backButton];
    }else{
        [self popViewControllerAnimated:YES];
    }
}

#pragma mark - public
/**
 是否隐藏返回按钮.
 */
- (void)shouldHideLeftBackButton:(BOOL)flag{
    _backButton.hidden = flag;
}


#pragma mark - UIGestureRecognizerDelegate
// 子控制器大于 1 时，说明不在根控制器
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    return self.viewControllers.count > 1;
}

#pragma mark - UINavigationControllerDelegate

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
    if (self.viewControllers.count > 0) {
        UIButton *button = [UIButton buttonWithType:1];//[[UIButton alloc] init];
        [button setImage:[UIImage imageNamed:@"btn_back"] forState:0];
        [button addTarget:self action:@selector(back) forControlEvents:1<<6];
        button.frame = CGRectMake(0, 0, 34, 44);
        button.tintColor = [UIColor grayColor];
        _backButton = button;
        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
        viewController.hidesBottomBarWhenPushed = YES;
    }
    if ([self respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.interactivePopGestureRecognizer.enabled = NO;
    }
    [super pushViewController:viewController animated:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
