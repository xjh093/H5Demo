//
//  JHNavigationController.h
//  JHKit
//
//  Created by HaoCold on 2017/2/10.
//  Copyright © 2017年 HaoCold. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JHNavigationControllerDelegate.h"

@interface JHNavigationController : UINavigationController

@property (nonatomic,    weak) id <JHNavigationControllerDelegate>backDelegate;

/**
 是否隐藏返回按钮.
 */
- (void)shouldHideLeftBackButton:(BOOL)flag;

@end

