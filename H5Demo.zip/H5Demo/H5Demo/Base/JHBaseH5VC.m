//
//  JHBaseH5VC.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/17.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHBaseH5VC.h"
#import "UIScreen+JHCategory.h"
#import "JHURLParser.h"
#import "JHUIViewControllerDecoupler.h"
#import "JHNavigationController.h"
#import "MJRefresh.h"

#define kJH_ShowProgress 1

@interface JHBaseH5VC ()<WKNavigationDelegate,UIScrollViewDelegate>

@property (nonatomic,  strong) UIScrollView *scrollView;

#if kJH_ShowProgress
@property (nonatomic,  strong) UIView *loadProgressView;
#endif

@end

@implementation JHBaseH5VC

- (void)dealloc{
    // 不置空代理 会崩溃
    _webView.scrollView.delegate = nil;

#if kJH_ShowProgress
    [_webView removeObserver:self forKeyPath:@"estimatedProgress"];
#endif
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.scrollView];
    [_scrollView addSubview:self.webView];
    
    if (_autoLoadURL) {
        [self updateViewFrame];
        [self loadURL:_url];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -------------------------------------视图-------------------------------------------

- (void)xjh_setupViewFrame
{

}

#pragma mark -------------------------------------事件-------------------------------------------

#pragma mark - public
- (void)pushSpecifiedVC:(NSString *)VCString parameter:(NSDictionary *)dic{
    UIViewController *vc = [JHUIViewControllerDecoupler jh_controllerFromString:VCString paramter:dic];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)presentSpecifiedVC:(NSString *)VCString parameter:(NSDictionary *)dic navigation:(BOOL)flag{
    UIViewController *vc = [JHUIViewControllerDecoupler jh_controllerFromString:VCString paramter:dic];
    JHNavigationController *nav = nil;
    if (flag) {
        nav = [[JHNavigationController alloc] initWithRootViewController:vc];
    }
    [self presentViewController:nav?nav:vc animated:YES completion:nil];
}

- (UIViewController *)fetchSpecifiedVC:(NSString *)VCString parameter:(NSDictionary *)dic{
    return [JHUIViewControllerDecoupler jh_controllerFromString:VCString paramter:dic];
}

- (void)shouldHideLeftBackButton:(BOOL)flag{
    [(JHNavigationController *)self.navigationController shouldHideLeftBackButton:flag];
}

- (void)loadURL:(NSString *)url{
    
    if ([url hasPrefix:@"http"]) {
        NSURLRequest* request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
        [_webView loadRequest:request];
    }else if([url hasPrefix:@"#"]) {
#if kH5Debug
        // 联调模式
        NSURLRequest* request = [NSURLRequest requestWithURL:[NSURL URLWithString:kH5Path(url)]];
        [_webView loadRequest:request];
#else
        url = [NSString stringWithFormat:@"file://%@",kH5Path(url)];
        NSURLRequest* request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
        [_webView loadRequest:request];
#endif
    }
}

- (void)updateViewFrame{
    CGFloat Y = 0;
    CGFloat H = 0;
    if (_frameType == JHWebViewFrameType_FullScreen) {
        Y = [UIScreen jh_statusBarHeight];
        H = kScreenHeight - Y - [UIScreen jh_bottomSafeSpace];
    }else if (_frameType == JHWebViewFrameType_Navigation) {
        Y = CGRectGetMaxY(self.navigationController.navigationBar.frame);
        H = kScreenHeight - Y - [UIScreen jh_bottomSafeSpace];
    }else if (_frameType == JHWebViewFrameType_Tabbar) {
        Y = [UIScreen jh_statusBarHeight];
        H = CGRectGetMinY(self.tabBarController.tabBar.frame) - Y;
    }else if (_frameType == JHWebViewFrameType_Both) {
        Y = CGRectGetMaxY(self.navigationController.navigationBar.frame);
        H = CGRectGetMinY(self.tabBarController.tabBar.frame) - Y;
    }
    
    _scrollView.frame = CGRectMake(0, Y, kScreenWidth, H);
    _webView.frame = _scrollView.bounds;
}

- (void)beginRefresh{
    [_scrollView.mj_header beginRefreshing];
}

- (void)endRefresh{
    [_scrollView.mj_header endRefreshing];
    [_scrollView.mj_footer endRefreshing];
}

//客户端用户交互，由客户端主动发起前端回调
//qb://clientUserAction/(前端页面路由)?action=(refresh,loadMore,click)&target=(当action=click时需要添加target参数back,title,subtitle)
- (void)evaluateJavaScript:(NSString *)url
{
    NSURL *URL = [NSURL URLWithString:[url stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLQueryAllowedCharacterSet]];
    [JHURLParser callback:URL response:@"{}" forVC:self];
}

#pragma mark - private

- (void)xjh_shouldAddHeaderRefresh:(BOOL)flag{
    if (flag) {
        _scrollView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(xjh_headerRefresh)];
    }
}

- (void)xjh_shouldAddFooterRefresh:(BOOL)flag{
    if (flag) {
        _scrollView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(xjh_footerRefresh)];
    }
}

- (void)xjh_headerRefresh
{
    NSString *url = [NSString stringWithFormat:@"%@clientUserAction%@?action=refresh",kScheme,_identifier];
    [self evaluateJavaScript:url];
}

- (void)xjh_footerRefresh
{
    NSString *url = [NSString stringWithFormat:@"%@clientUserAction%@?action=loadMore",kScheme,_identifier];
    [self evaluateJavaScript:url];
}

#pragma mark - WKNavigationDelegate

// 请求之前，决定是否要跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    NSLog(@"%s:",__func__);
    NSURL *URL = navigationAction.request.URL;
    NSLog(@"open URL:%@",URL);
    if ([URL.absoluteString hasPrefix:kScheme]) {
        [JHURLParser parseURL:URL forVC:self];
        decisionHandler(WKNavigationActionPolicyCancel);
    }else{
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}

// 接收到相应数据后，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{
    NSLog(@"%s",__func__);
    decisionHandler(WKNavigationResponsePolicyAllow);
}

// 页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation{
    NSLog(@"%s",__func__);
}

// 主机地址被重定向时调用
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(null_unspecified WKNavigation *)navigation{
    NSLog(@"%s",__func__);
}

// 页面加载失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error{
    NSLog(@"%s,error:%@",__func__,error);
}

// 当内容开始返回时调用
- (void)webView:(WKWebView *)webView didCommitNavigation:(null_unspecified WKNavigation *)navigation{
    NSLog(@"%s",__func__);
}

// 页面加载完毕时调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation{
    NSLog(@"%s:%@",__func__,webView.URL.absoluteString);
}

//跳转失败时调用
- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error{
    NSLog(@"%s,error:%@",__func__,error);
}

#pragma mark - UIScrollViewDelegate

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
#if 0
    return nil;
#else
    return _webView.scrollView.subviews[0];
#endif
}

#pragma mark - estimatedProgress
#if kJH_ShowProgress
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context
{
    if ([keyPath isEqualToString:@"estimatedProgress"]) {
        NSLog(@"%@",change[@"new"]);
        
        CGFloat value = [change[@"new"] floatValue];
        [UIView animateWithDuration:0.25 animations:^{
            self.loadProgressView.jh_w = kScreenWidth*value;
        } completion:^(BOOL finished) {
            if (value == 1.0) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    self.loadProgressView.jh_w = 0;
                });
            }
        }];
    }
}
#endif

#pragma mark -------------------------------------懒加载-----------------------------------------

- (UIScrollView *)scrollView{
    if (!_scrollView) {
        // 为什么要添加一个 view ?
        // https://blog.csdn.net/xjh093/article/details/78899390
        [self.view addSubview:[[UIView alloc] init]];
        
        _scrollView = [[UIScrollView alloc] init];
    }
    return _scrollView;
}

#if kJH_ShowProgress
- (UIView *)loadProgressView{
    if (!_loadProgressView) {
        UIView *view = [[UIView alloc] init];
        view.frame = CGRectMake(0, 0, 0, 3);
        view.backgroundColor = [UIColor orangeColor];
        _loadProgressView = view;
    }
    return _loadProgressView;
}
#endif

- (WKWebView *)webView{
    if (!_webView) {
        _webView = [[WKWebView alloc] init];
        _webView.navigationDelegate = self;
        // 界面 缩放
        _webView.scrollView.delegate = self;
        
#if kJH_ShowProgress
        [_webView addSubview:self.loadProgressView];
        [_webView addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:NULL];
#endif
    }
    return _webView;
}

- (void)setFrameType:(JHWebViewFrameType)frameType{
    _frameType = frameType;
}

- (void)setNavTitle:(NSString *)navTitle{
    _navTitle = navTitle;
    self.navigationItem.title = navTitle;
}

- (void)setRefreshType:(JHRefreshType)refreshType{
    _refreshType = refreshType;
    
    if (refreshType == JHRefreshType_None) {
        
    }else if (refreshType == JHRefreshType_Both) {
        [self xjh_shouldAddHeaderRefresh:YES];
        [self xjh_shouldAddFooterRefresh:YES];
    }else if (refreshType == JHRefreshType_Top) {
        [self xjh_shouldAddHeaderRefresh:YES];
    }else if (refreshType == JHRefreshType_Bottom) {
        [self xjh_shouldAddFooterRefresh:YES];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
