//
//  JHNavigationControllerDelegate.h
//  JHKit
//
//  Created by xuejinghao on 2018/5/4.
//  Copyright © 2018年 HaoCold. All rights reserved.
//

#ifndef JHNavigationControllerDelegate_h
#define JHNavigationControllerDelegate_h

@protocol JHNavigationControllerDelegate<NSObject>
- (void)didClickBackButton:(UIButton *)button;
@end

#endif /* JHNavigationControllerDelegate_h */
