//
//  JHBaseH5VC.h
//  H5Demo
//
//  Created by xuejinghao on 2018/7/17.
//  Copyright © 2018年 HN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

#define kBaseURL @""
#define kScheme  @"qb://"
#if 0 // 远程调试
#define kH5Debug                  1
#define kH5Path(subfix)           [@"http://192.168.60.18:8080/" stringByAppendingString:subfix]
#else // 本地调试 - 上架选择这个
#define kH5Debug                  0
#define kH5Path(suffix) [[[NSBundle mainBundle] pathForResource:@"index" ofType:@"html" inDirectory:@"H5"] stringByAppendingString:suffix]
#endif

typedef NS_ENUM(NSUInteger, JHWebViewFrameType) {
    JHWebViewFrameType_FullScreen,  /**< 全屏(安全区域内)*/
    JHWebViewFrameType_Navigation,  /**< 导航条以下的区域(安全区域内)*/
    JHWebViewFrameType_Tabbar,      /**< Tabbar以上的区域(安全区域内)*/
    JHWebViewFrameType_Both         /**< 导航条与Tabbar之间的区域*/
};

typedef NS_ENUM(NSUInteger, JHRefreshType) {
    JHRefreshType_None,     /**< 没有刷新*/
    JHRefreshType_Both,     /**< 下拉、上拉都有*/
    JHRefreshType_Top,      /**< 有下拉刷新*/
    JHRefreshType_Bottom    /**< 有上拉加载*/
};

@interface JHBaseH5VC : UIViewController

/**
 WKWebView.
 */
@property (nonatomic,  strong) WKWebView *webView;

/**
 设置 webView 的尺寸类型.子类在设置好frameType后，调用方法`updateViewFrame`更新view的frame
 */
@property (nonatomic,  assign) JHWebViewFrameType  frameType;

/**
 设置导航条标题.
 */
@property (nonatomic,    copy) NSString *navTitle;

/**
 设置 下拉，上拉等.
 */
@property (nonatomic,  assign) JHRefreshType  refreshType;

/**
 要加载的url.
 */
@property (nonatomic,    copy) NSString *url;

/**
 自动加载url 在 -viewDidLoad 内.
 */
@property (nonatomic,  assign) BOOL  autoLoadURL;

/**
 页面唯一标志.此处用的`url`
 */
@property (nonatomic,    copy) NSString *identifier;


#pragma mark - push & present
/**
 push 指定的控制器.
 
 @param VCString 控制器字符串.
 @param dic 要传递的参数.
 */
- (void)pushSpecifiedVC:(NSString *)VCString parameter:(NSDictionary *)dic;

/**
 present 指定的控制器.
 
 @param VCString 控制器字符串.
 @param dic 要传递的参数.
 @param flag 是否需要导航.
 */
- (void)presentSpecifiedVC:(NSString *)VCString parameter:(NSDictionary *)dic navigation:(BOOL)flag;

/**
 获取指定的控制器.
 
 @param VCString 控制器字符串.
 @param dic 要传递的参数.
 @return UIViewController.
 */
- (UIViewController *)fetchSpecifiedVC:(NSString *)VCString parameter:(NSDictionary *)dic;

/**
 是否隐藏返回按钮.
 */
- (void)shouldHideLeftBackButton:(BOOL)flag;

/**
 加载url.
 */
- (void)loadURL:(NSString *)url;

/**
 子类在设置好frameType后，调用此方法更新view的frame.
 */
- (void)updateViewFrame;

/**
 开始下拉刷新
 */
- (void)beginRefresh;

/**
 停止上拉，下拉刷新
 */
- (void)endRefresh;

/**
 回调 url 给 H5
 */
- (void)evaluateJavaScript:(NSString *)url;

@end
