//
//  JHNetworkManager.m
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import "JHNetworkManager.h"
#import "AFNetworking.h"

#define kJH_USE_AFN 0

@implementation JHNetworkManager

#pragma mark - public
+ (instancetype)manager{
    static JHNetworkManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[JHNetworkManager alloc] init];
    });
    return manager;
}

+ (void)GET:(NSString *)url parameters:(NSDictionary *)dic success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure{
#if kJH_USE_AFN
    [self AFN_GET:url parameters:dic success:success failure:failure];
#else
    [self JH_GET:url parameters:dic success:success failure:failure];
#endif
}

+ (void)POST:(NSString *)url parameters:(NSDictionary *)dic success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure{
#if kJH_USE_AFN
    [self AFN_POST:url parameters:dic success:success failure:failure];
#else
    [self JH_POST:url parameters:dic success:success failure:failure];
#endif
}

+ (void)uploadImage:(UIImage *)image parameters:(NSDictionary *)dic success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure{
#if kJH_USE_AFN
    [self AFN_uploadImage:image parameters:dic success:success failure:failure];
#else
    [self JH_uploadImage:image parameters:dic success:success failure:failure];
#endif
}

+ (void)uploadVideo:(NSURL *)path parameters:(NSDictionary *)dic success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure{
#if kJH_USE_AFN
    [self AFN_uploadVideo:path parameters:dic success:success failure:failure];
#else
    [self JH_uploadVideo:path parameters:dic success:success failure:failure];
#endif
}

#pragma mark - private
#pragma mark --- AFN
+ (void)AFN_GET:(NSString *)url parameters:(NSDictionary *)dic success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer.timeoutInterval = 10;
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithArray:@[@"text/html",@"application/json"]];
    [manager GET:url parameters:dic progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"GET error:%@",error);
        if (failure) {
            failure(error);
        }
    }];
    
    //
#if kUSE_JHRequestDebugView
    [[JHRequestDebugView defaultDebugView] jh_set_GET_URL:URL parameter:dic];
#endif
}

+ (void)AFN_POST:(NSString *)url parameters:(NSDictionary *)dic success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer.timeoutInterval = 10;
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithArray:@[@"text/html",@"application/json"]];
    
    [manager POST:url parameters:dic progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"POST error:%@",error);
        if (failure) {
            failure(error);
        }
    }];
    
    //
#if kUSE_JHRequestDebugView
    [[JHRequestDebugView defaultDebugView] jh_set_POST_URL:URL parameter:dic];
#endif
}

+ (void)AFN_uploadImage:(UIImage *)image parameters:(NSDictionary *)dic success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];

    NSData *imageData = UIImagePNGRepresentation(image);
    
    [manager POST:@"" parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        [formData appendPartWithFileData:imageData name:@"file" fileName:@"1.png" mimeType:@"image/png"];
    } progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"uploadImage error:%@",error);
        failure(error);
    }];
}

+ (void)AFN_uploadVideo:(NSURL *)path parameters:(NSDictionary *)dic success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    NSData *videoData = [NSData dataWithContentsOfFile:@"kVideoSandboxPath"];
    
    [manager POST:@"" parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        [formData appendPartWithFileData:videoData name:@"file" fileName:@"videoName" mimeType:@"mp4"];
    } progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"uploadVideo error:%@",error);
        failure(error);
    }];
}

#pragma mark ---

+ (void)JH_GET:(NSString *)url parameters:(NSDictionary *)dic success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure{
    [self JH_requestType:0 url:url parameters:dic success:success failure:failure];
}

+ (void)JH_POST:(NSString *)url parameters:(NSDictionary *)dic success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure{
    [self JH_requestType:1 url:url parameters:dic success:success failure:failure];
}

+ (void)JH_uploadImage:(UIImage *)image parameters:(NSDictionary *)dic success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure{
    [self JH_requestForUpload:@"" image:image path:nil success:success failure:failure];
}

+ (void)JH_uploadVideo:(NSURL *)path parameters:(NSDictionary *)dic success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure{
    [self JH_requestForUpload:@"" image:nil path:path success:success failure:failure];
}

+ (void)JH_requestType:(NSInteger)type url:(NSString *)url parameters:(NSDictionary *)dic success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure{
    
    if (url.length == 0) {
        NSLog(@"url lenght is 0.");
        return;
    }
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    if (dic.count > 0) {
        NSMutableArray *marr = @[].mutableCopy;
        for (NSString *key in dic.allKeys) {
            NSString *value = dic[key];
            NSString *param = [NSString stringWithFormat:@"%@=%@",key,value];
            [marr addObject:param];
        }
        
        NSString *params = [marr componentsJoinedByString:@"&"];
        params = [params stringByAddingPercentEncodingWithAllowedCharacters:
                  NSCharacterSet.URLQueryAllowedCharacterSet];
        
        // GET
        if (type == 0) {
            url = [NSString stringWithFormat:@"%@?%@",url,params];
            
            request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
        }else{
            NSMutableURLRequest *mRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
            mRequest.HTTPMethod = @"POST";
            mRequest.HTTPBody = [params dataUsingEncoding:NSUTF8StringEncoding];
            request = mRequest;
        }
    }
    
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@"\ndata:%@\nresponse:%@\nerror:%@",data,response,error);
        if (data) {
            NSError *err;
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&err];
            if (err) {
                failure(err);
            }else{
                success(dic);
            }
        }else if (error){
            failure(error);
        }
    }] resume];
}

+ (NSURLRequest *)JH_requestForUpload:(NSString *)url image:(UIImage *)image path:(NSURL *)path success:(JHNetworkSuccess)success failure:(JHNetworkFailure)failure{
    
    if (url.length == 0) {
        NSLog(@"url lenght is 0.");
        return nil;
    }
    
    NSString *uploadName = @"file";
    NSString *savedName  = @"1.png";
    if (path) {
        savedName = @"1.mp4";
    }
    
    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    request.HTTPMethod = @"POST";
    request.timeoutInterval = 15.0;
    
    NSMutableData *requestMutableData=[NSMutableData data];
    
    //1.\r\n--Boundary+72D4CD655314C423\r\n
    static NSString *boundary = @"com.haocold.JHWerRequest";
    NSMutableString *myString = [NSMutableString stringWithFormat:@"\r\n--%@\r\n",boundary];
    
    //2. Content-Disposition: form-data; name="uploadFile"; filename="001.png"\r\n
    [myString appendString:[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"%@\"\r\n",uploadName,savedName]];
    
    //3. Content-Type:image/png \r\n  // 图片类型为png
    [myString appendString:[NSString stringWithFormat:@"Content-Type:application/octet-stream\r\n"]];
    
    //4. Content-Transfer-Encoding: binary\r\n\r\n  // 编码方式
    [myString appendString:@"Content-Transfer-Encoding: binary\r\n\r\n"];
    
    //转换成为二进制数据
    [requestMutableData appendData:[myString dataUsingEncoding:NSUTF8StringEncoding]];
    
    //5.文件数据部分
    if (image) {
        NSData *data = UIImageJPEGRepresentation(image, 1);
        [requestMutableData appendData:data];
    }else{
        NSData *fileData = [NSData dataWithContentsOfURL:path];
        [requestMutableData appendData:fileData];
    }
    
    //6. \r\n--Boundary+72D4CD655314C423--\r\n  // 结束
    [requestMutableData appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    //设置请求体
    request.HTTPBody=requestMutableData;
    
    //设置请求头
    NSString *headStr=[NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    [request setValue:headStr forHTTPHeaderField:@"Content-Type"];
    
    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            
        }
    }] resume];
    
    return request;
}

@end
