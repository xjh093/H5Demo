//
//  NSString+JHCategory.h
//  JHKit
//
//  Created by HaoCold on 2017/12/21.
//  Copyright © 2017年 HaoCold. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import <Foundation/Foundation.h>

@interface NSString (JHCategory)

/// 用*替代中间的字符串 & replace substring at middle with '*'
+ (NSString *)jh_hideMiddleString:(NSString *)string;

/// Replace substring of 'string' with specified string 'replace'.
+ (NSString *)jh_hideMiddleString:(NSString *)string fromIndex:(NSInteger)index length:(NSInteger)length replaceString:(NSString *)replace;

/// 当前版本号
+ (NSString *)jh_bundleShortVersionString;

/// 当前内部版本号
+ (NSString *)jh_bundleVersion;

/// time(00:00:00) from a integer value
+ (NSString *)jh_timeForNumber:(NSUInteger)seconds;

// 判断身份证
+ (BOOL)jh_isValidateIDCardNumber:(NSString *)value;

/// 是否是纯数字
- (BOOL)jh_isPureDigital;

/// dic -> json string
+ (NSString *)jh_JSONStringFromDictionary:(NSDictionary *)dic;

/// json string -> dic
+ (NSDictionary *)jh_dictionaryFromJSONString:(NSString *)jsonString;

/// array -> json string
+ (NSString *)jh_JSONStringFromArray:(NSArray *)array;

/// json string -> array
+ (NSArray *)jh_arrayFromJSONString:(NSString *)jsonString;

@end
