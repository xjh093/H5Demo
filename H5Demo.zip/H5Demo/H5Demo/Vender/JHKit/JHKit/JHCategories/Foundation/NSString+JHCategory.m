//
//  NSString+JHCategory.m
//  JHKit
//
//  Created by HaoCold on 2017/12/21.
//  Copyright © 2017年 HaoCold. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import "NSString+JHCategory.h"

@implementation NSString (JHCategory)

+ (NSString *)jh_hideMiddleString:(NSString *)string{
    if (string.length <= 2) {
        return string;
    }
    
    if (string.length == 3) {
        return [string stringByReplacingCharactersInRange:NSMakeRange(1, 1) withString:@"*"];
    }
    
    NSInteger mid = string.length/2;
    
    NSString *preString = [string substringToIndex:mid];
    NSString *subString = [string substringFromIndex:mid];
    //NSLog(@"preString1:%@",preString);
    //NSLog(@"subString1:%@",subString);
    
    mid = preString.length/2;
    NSRange range = [preString rangeOfString:[preString substringFromIndex:mid]];
    preString = [preString stringByReplacingCharactersInRange:range withString:({
        NSMutableString *mstr = @"".mutableCopy;
        for (int i = 0; i < range.length; ++i) {
            [mstr appendString:@"*"];
        }
        mstr;
    })];
    //NSLog(@"preString2:%@",preString);
    
    mid = subString.length/2;
    range = [subString rangeOfString:[subString substringToIndex:mid]];
    subString = [subString stringByReplacingCharactersInRange:range withString:({
        NSMutableString *mstr = @"".mutableCopy;
        for (int i = 0; i < range.length; ++i) {
            [mstr appendString:@"*"];
        }
        mstr;
    })];
    //NSLog(@"subString2:%@",subString);
    
    return [NSString stringWithFormat:@"%@%@",preString,subString];
}

+ (NSString *)jh_hideMiddleString:(NSString *)string fromIndex:(NSInteger)index length:(NSInteger)length replaceString:(NSString *)replace{
    
    if (index + length > string.length) {
        return [NSString jh_hideMiddleString:string];
    }
    
    NSRange range = NSMakeRange(index, length);
    return [string stringByReplacingCharactersInRange:range withString:replace];
}

+ (NSString *)jh_bundleShortVersionString{
    return [NSString stringWithFormat:@"%@",[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]];
}

+ (NSString *)jh_bundleVersion{
    return [NSString stringWithFormat:@"%@",[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"]];
}

+ (NSString *)jh_timeForNumber:(NSUInteger)seconds{
    NSUInteger hour = seconds/3600;
    NSUInteger minute = (seconds%3600)/60;
    NSUInteger second = (seconds%3600)%60;
    NSString *time = [NSString stringWithFormat:@"%02lu:%02lu:%02lu",(unsigned long)hour,(unsigned long)minute,(unsigned long)second];
    return time;
}

+ (BOOL)jh_isValidateIDCardNumber:(NSString *)value
{
    value = [value stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSInteger length = 0;
    
    if (!value) {
        return NO;
    }else {
        length = value.length;
        if (length != 15 && length != 18) {
            return NO;
        }
    }
    
    // 省份代码
    NSArray *areasArray =@[@"11",@"12", @"13",@"14", @"15",@"21", @"22",@"23", @"31",@"32", @"33",@"34", @"35",@"36", @"37",@"41", @"42",@"43", @"44",@"45", @"46",@"50", @"51",@"52", @"53",@"54", @"61",@"62", @"63",@"64", @"65",@"71", @"81",@"82", @"91"];
    
    NSString *valueStart2 = [value substringToIndex:2];
    BOOL areaFlag = NO;
    
    for (NSString *areaCode in areasArray) {
        
        if ([areaCode isEqualToString:valueStart2]){
            areaFlag = YES;
            break;
        }
    }
    
    if (!areaFlag){
        return NO;
    }
    
    NSRegularExpression *regularExpression;
    NSUInteger numberofMatch;
    NSInteger year = 0;
    
    switch (length) {
        case 15:
            year = [value substringWithRange:NSMakeRange(6,2)].intValue +1900;
            
            if (year %4 ==0 || (year %100 ==0 && year %4 ==0)) {
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$"
                                                                        options:NSRegularExpressionCaseInsensitive
                                                                          error:nil];//测试出生日期的合法性
            }else {
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$"
                                                                        options:NSRegularExpressionCaseInsensitive
                                                                          error:nil];//测试出生日期的合法性
            }
            
            numberofMatch = [regularExpression numberOfMatchesInString:value
                                                               options:NSMatchingReportProgress
                                                                 range:NSMakeRange(0, value.length)];
            if(numberofMatch > 0) {
                return YES;
            }else {
                return NO;
            }
            
        case 18:
            
            year = [value substringWithRange:NSMakeRange(6,4)].intValue;
            if (year %4 ==0 || (year %100 ==0 && year %4 ==0)) {
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$"
                                                                        options:NSRegularExpressionCaseInsensitive
                                                                          error:nil];//测试出生日期的合法性
                
            }else {
                
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$"
                                                                        options:NSRegularExpressionCaseInsensitive
                                                                          error:nil];//测试出生日期的合法性
                
            }
            
            numberofMatch = [regularExpression numberOfMatchesInString:value
                                                               options:NSMatchingReportProgress
                                                                 range:NSMakeRange(0, value.length)];
            if(numberofMatch > 0) {
                
                int S =
                ([value substringWithRange:NSMakeRange(0,1)].intValue +
                 [value substringWithRange:NSMakeRange(10,1)].intValue) *7 +
                ([value substringWithRange:NSMakeRange(1,1)].intValue +
                 [value substringWithRange:NSMakeRange(11,1)].intValue) *9 +
                ([value substringWithRange:NSMakeRange(2,1)].intValue +
                 [value substringWithRange:NSMakeRange(12,1)].intValue) *10 +
                ([value substringWithRange:NSMakeRange(3,1)].intValue +
                 [value substringWithRange:NSMakeRange(13,1)].intValue) *5 +
                ([value substringWithRange:NSMakeRange(4,1)].intValue +
                 [value substringWithRange:NSMakeRange(14,1)].intValue) *8 +
                ([value substringWithRange:NSMakeRange(5,1)].intValue +
                 [value substringWithRange:NSMakeRange(15,1)].intValue) *4 +
                ([value substringWithRange:NSMakeRange(6,1)].intValue +
                 [value substringWithRange:NSMakeRange(16,1)].intValue) *2 +
                 [value substringWithRange:NSMakeRange(7,1)].intValue *1 +
                 [value substringWithRange:NSMakeRange(8,1)].intValue *6 +
                 [value substringWithRange:NSMakeRange(9,1)].intValue *3;
                
                int Y = S %11;
                NSString *M =@"F";
                NSString *JYM =@"10X98765432";
                M = [JYM substringWithRange:NSMakeRange(Y,1)];// 判断校验位
                if ([M isEqualToString:[value substringWithRange:NSMakeRange(17,1)]]) {
                    return YES;// 检测ID的校验位
                }else {
                    return NO;
                }
            }else {
                return NO;
            }
        default:
            return NO;
    }
}


- (BOOL)jh_isPureDigital{
    if (![self judge]) {
        return NO;
    }
    
    for (int i = 0; i < self.length; ++i) {
        unichar c = [self characterAtIndex:i];
        if (c < '0' || c > '9') {
            return NO;
        }
    }
    
    return YES;
}

- (BOOL)jh_isPureAlphabet{
    if (![self judge]) {
        return NO;
    }
    
    for (int i = 0; i < self.length; ++i) {
        unichar c = [self characterAtIndex:i];
        if (c < 'A' || c > 'z' || (c > 'Z' && c < 'a')) {
            return NO;
        }
    }
    
    return YES;
}


- (BOOL)judge{
    if (![self isKindOfClass:[NSString class]]) {
        return NO;
    }
    
    if (self.length == 0) {
        return NO;
    }
    
    return YES;
}

+ (NSString *)jh_JSONStringFromDictionary:(NSDictionary *)dic{
    if ([dic isKindOfClass:[NSString class]]) {
        return (NSString *)dic;
    }
    
    if ([dic isKindOfClass:[NSDictionary class]]) {
        NSData *data = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
        NSString *string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        if (string.length) {
            return string;
        }
    }
    
    return @"";
}

+ (NSDictionary *)jh_dictionaryFromJSONString:(NSString *)jsonString{
    if ([jsonString isKindOfClass:[NSDictionary class]]) {
        return (NSDictionary *)jsonString;
    }
    
    if ([jsonString isKindOfClass:[NSString class]]) {
        NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        if (dic) {
            return dic;
        }
    }
    return nil;
}

/// array -> json string
+ (NSString *)jh_JSONStringFromArray:(NSArray *)array{
    if ([array isKindOfClass:[NSString class]]) {
        return (NSString *)array;
    }
    
    if ([array isKindOfClass:[NSArray class]]) {
        NSData *data = [NSJSONSerialization dataWithJSONObject:array options:NSJSONWritingPrettyPrinted error:nil];
        NSString *string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        if (string.length) {
            return string;
        }
    }
    return @"";
}

/// json string -> array
+ (NSArray *)jh_arrayFromJSONString:(NSString *)jsonString{
    if ([jsonString isKindOfClass:[NSArray class]]) {
        return (NSArray *)jsonString;
    }
    
    if ([jsonString isKindOfClass:[NSString class]]) {
        NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
        NSArray *array = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        if (array) {
            return array;
        }
    }
    return nil;
}

@end
