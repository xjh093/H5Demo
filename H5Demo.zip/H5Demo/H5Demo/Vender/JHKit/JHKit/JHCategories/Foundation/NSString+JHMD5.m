//
//  NSString+JHMD5.m
//  JHKit
//
//  Created by Lightech on 15-1-10.
//  Copyright (c) 2015年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2015 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import "NSString+JHMD5.h"
#import <CommonCrypto/CommonDigest.h>

@implementation NSString (JHMD5)

+ (NSString *)MD5Encrypt:(NSString *)inputStr  /**< md5加密*/
{
    const char* str = [inputStr UTF8String];
    unsigned char res[CC_MD5_DIGEST_LENGTH];
    
    CC_MD5(str, (CC_LONG)strlen(str), res);
    
    NSMutableString *outStr = [NSMutableString string];
    for (int i = 0; i < CC_MD5_DIGEST_LENGTH; i++) {
        [outStr appendFormat:@"%02X",res[i]];
    }
    return outStr;
}

+ (NSString *)jh_MD5LowercaseString:(NSString *)inputStr
{
    if (inputStr.length == 0) return @"inputStr length is 0!";
    return [[NSString MD5Encrypt:inputStr] lowercaseString];
}

+ (NSString *)jh_MD5UppercaseString:(NSString *)inputStr
{
    if (inputStr.length == 0) return @"inputStr length is 0!";
    return [[NSString MD5Encrypt:inputStr] uppercaseString];
}

+ (NSString *)jh_MD5String:(NSString *)inputStr salt:(NSString *)salt
{
    if (inputStr.length == 0) return @"inputStr length is 0!";
    if (salt.length == 0) return @"salt length is 0!";
    NSMutableString *xStr = [NSMutableString stringWithString:inputStr];
    [xStr appendString:salt];
    [xStr insertString:salt atIndex:xStr.length*0.5];
    return [NSString MD5Encrypt:xStr];
}

+ (NSString *)jh_base64EncryptString:(NSString *)inputStr
{
    if (inputStr.length == 0) return @"inputStr length is 0!";
    NSData *data = [inputStr dataUsingEncoding:NSUTF8StringEncoding];
    return [data base64EncodedStringWithOptions:0];
}

+ (NSString *)jh_base64DecryptString:(NSString *)inputStr
{
    if (inputStr.length == 0) return @"inputStr length is 0!";
    NSData *data = [[NSData alloc] initWithBase64EncodedString:inputStr options:0];
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}


- (NSString *)jh_MD5LowercaseString{
    return [[NSString MD5Encrypt:self] lowercaseString];
}

- (NSString *)jh_MD5UppercaseString{
    return [[NSString MD5Encrypt:self] uppercaseString];
}

- (NSString *)jh_MD5StringWithSalt:(NSString *)salt{
    NSMutableString *xStr = [NSMutableString stringWithString:self];
    [xStr appendString:salt];
    [xStr insertString:salt atIndex:xStr.length*0.5];
    return [NSString MD5Encrypt:xStr];
}

- (NSString *)jh_base64Encrypt{
    NSData *data = [self dataUsingEncoding:NSUTF8StringEncoding];
    return [data base64EncodedStringWithOptions:0];
}

- (NSString *)jh_base64Decrypt{
    NSData *data = [[NSData alloc] initWithBase64EncodedString:self options:0];
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

@end
