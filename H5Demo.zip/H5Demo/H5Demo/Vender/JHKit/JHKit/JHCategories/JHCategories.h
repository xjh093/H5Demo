//
//  JHCategories.h
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#ifndef JHCategories_h
#define JHCategories_h

// 常用UI控件，链式语法
#import "JHChainable.h"

// frame布局，自动布局
#import "JHFrameLayout.h"

// 圆角遮罩，爱心遮罩
#import "UIView+JHViewCorner.h"

// 列表无数据占位图
#import "UITableView+JHNoData.h"
#import "UICollectionView+JHNoData.h"

// UIResponder 路由
#import "UIResponder+JHRouter.h"
#import "NSObject+PerformSelector.h"

// UI
#import "UIFont+JHFit.h"
#import "UITabBar+JHBadge.h"
#import "UIColor+JHCategory.h"
#import "UIImage+JHCategory.h"
#import "UIScreen+JHCategory.h"
#import "UIView+JHRectCategory.h"
#import "UIView+JHDrawCategory.h"

// Foundation
#import "NSString+JHMD5.h"
#import "NSString+JHAES256.h"
#import "NSString+JHCategory.h"
#import "NSArray+JHUnicode.h"
#import "NSDictionary+JHUnicode.h"
#import "NSUserDefaults+JHCategory.h"

#endif

