//
//  UISwitch+JHCategory.m
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import "UISwitch+JHCategory.h"
#import "UIView+JHCategory.h"
#import "UIFont+JHCategory.h"
#import "UIColor+JHCategory.h"

@implementation UISwitch (JHCategory)

JH_new_m(UISwitch)
JH_tag_m(UISwitch)
JH_bind_m(UISwitch)
JH_frame_m(UISwitch)
JH_alpha_m(UISwitch)
JH_bgColor_m(UISwitch)
JH_bdColor_m(UISwitch)
JH_bdWidth_m(UISwitch)
JH_cnRadius_m(UISwitch)
JH_mtBounds_m(UISwitch)
JH_addToView_m(UISwitch)

- (UISwitch *(^)(id))jh_tintColor{
    JHLog();
    return ^id(id tintColor){
        if ([tintColor isKindOfClass:[UIColor class]]) {
            self.tintColor = tintColor;
        }else if ([tintColor isKindOfClass:[NSString class]]){
            self.tintColor = [UIColor jhColor:tintColor];
        }
        return self;
    };
}

- (UISwitch *(^)(id))jh_onTintColor{
    JHLog();
    return ^id(id onTintColor){
        if ([onTintColor isKindOfClass:[UIColor class]]) {
            self.onTintColor = onTintColor;
        }else if ([onTintColor isKindOfClass:[NSString class]]){
            self.onTintColor = [UIColor jhColor:onTintColor];
        }
        return self;
    };
}
- (UISwitch *(^)(id))jh_thTintColor{
    JHLog();
    return ^id(id thTintColor){
        if ([thTintColor isKindOfClass:[UIColor class]]) {
            self.thumbTintColor = thTintColor;
        }else if ([thTintColor isKindOfClass:[NSString class]]){
            self.thumbTintColor = [UIColor jhColor:thTintColor];
        }
        return self;
    };
}
- (UISwitch *(^)(id))jh_onImage{
    JHLog();
    return ^id(id onImage){
        if ([onImage isKindOfClass:[NSString class]]) {
            self.onImage = [UIImage imageNamed:onImage];
        }else if ([onImage isKindOfClass:[UIImage class]]){
            self.onImage = onImage;
        }
        return self;
    };
}
- (UISwitch *(^)(id))jh_offImage{
    JHLog();
    return ^id(id offImage){
        if ([offImage isKindOfClass:[NSString class]]) {
            self.offImage = [UIImage imageNamed:offImage];
        }else if ([offImage isKindOfClass:[UIImage class]]){
            self.offImage = offImage;
        }
        return self;
    };
}

@end
