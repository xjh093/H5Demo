//
//  UIButton+JHCategory.h
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import <UIKit/UIKit.h>
#import "JHCategoriesDeifne.h"

#define jhButton(type) jh_button(type)

@interface UIButton (JHCategory)

JH_tag_h(UIButton)
JH_bind_h(UIButton)
JH_frame_h(UIButton)
JH_alpha_h(UIButton)
JH_bgColor_h(UIButton)
JH_bdColor_h(UIButton)
JH_bdWidth_h(UIButton)
JH_cnRadius_h(UIButton)
JH_mtBounds_h(UIButton)
JH_addToView_h(UIButton)

+ (UIButton *(^)(id))jh_button;
- (UIButton *(^)(id))jh_title;
- (UIButton *(^)(id))jh_color;
- (UIButton *(^)(id))jh_font;
- (UIButton *(^)(id))jh_image;
- (UIButton *(^)(id,id,id))jh_target_selector_event;
- (UIButton *(^)(id))jh_bgImage;
- (UIButton *(^)(id))jh_hTitle;
- (UIButton *(^)(id))jh_hColor;
- (UIButton *(^)(id))jh_hImage;
- (UIButton *(^)(id))jh_sTitle;
- (UIButton *(^)(id))jh_sColor;
- (UIButton *(^)(id))jh_sImage;
- (UIButton *(^)(id))jh_tintColor;
- (UIButton *(^)(id))jh_imageUpTitleDown;
- (UIButton *(^)(id))jh_imageDownTitleUp;
- (UIButton *(^)(id))jh_imageRightTitleLeft;
- (UIButton *(^)(id))jh_imageLeftTitleRight;
- (UIButton *(^)())jh_imageCenterTitleCenter; /**< image and title all center*/
- (UIButton *(^)())jh_addUnderLine;

- (void)jhAddAttributeWithSubString:(NSString *)string value:(id)value forState:(UIControlState)state; /**< 添加富文本属性*/
- (void)jhAddAttributeWithSubString:(NSString *)string value:(id)value range:(NSRange)range forState:(UIControlState)state; /**< 添加富文本属性*/
- (void)jhAddLineSpace:(CGFloat)space forState:(UIControlState)state; /**< 设置行间距*/

@end
