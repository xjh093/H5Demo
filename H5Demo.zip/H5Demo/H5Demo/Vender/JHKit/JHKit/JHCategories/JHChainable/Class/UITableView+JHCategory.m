//
//  UITableView+JHCategory.m
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import "UITableView+JHCategory.h"
#import "UIView+JHCategory.h"
#import "UIFont+JHCategory.h"
#import "UIColor+JHCategory.h"

@implementation UITableView (JHCategory)
+ (UITableView *)jhTableView:(NSString *)frameStr style:(NSInteger)style target:(id)target view:(UIView *)view addToView:(BOOL)flag
{
    UITableView *xTableView = nil;
    if (style == 0 || style == 1)
        xTableView = [[UITableView alloc] initWithFrame:[view jhRectFromString:frameStr] style:style];
    
    xTableView.delegate = target;
    xTableView.dataSource = target;
    xTableView.tableFooterView = [[UIView alloc] init];
    xTableView.showsVerticalScrollIndicator = NO;
    xTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    xTableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    
    if (view){
         // automaticallyAdjustsScrollViewInsets is deprecated in iOS 11
         // add a view before tableView in superview
         // so we don't care the property any more
         // 2017-12-18 15:51:20
        [view addSubview:[[UIView alloc] init]];
        if (flag) {
            [view addSubview:xTableView];
        }
    }
    
    return xTableView;
}

JH_tag_m(UITableView)
JH_bind_m(UITableView)
JH_frame_m(UITableView)
JH_alpha_m(UITableView)
JH_bgColor_m(UITableView)
JH_bdColor_m(UITableView)
JH_bdWidth_m(UITableView)
JH_cnRadius_m(UITableView)
JH_mtBounds_m(UITableView)
JH_delegate_m(UITableView)
JH_addToView_m(UITableView)

+ (UITableView *(^)(id))jh_tableView{
    return ^id(id type){
        if ([type isKindOfClass:[NSNumber class]]) {
            UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectZero style:[type integerValue]];
            return tableView;
        }
        return nil;
    };
}

@end
