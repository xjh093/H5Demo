//
//  UISwitch+JHCategory.h
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import <UIKit/UIKit.h>
#import "JHCategoriesDeifne.h"

@interface UISwitch (JHCategory)

JH_new_h(UISwitch)
JH_tag_h(UISwitch)
JH_bind_h(UISwitch)
JH_frame_h(UISwitch)
JH_alpha_h(UISwitch)
JH_bgColor_h(UISwitch)
JH_bdColor_h(UISwitch)
JH_bdWidth_h(UISwitch)
JH_cnRadius_h(UISwitch)
JH_mtBounds_h(UISwitch)
JH_addToView_h(UISwitch)

- (UISwitch *(^)(id))jh_tintColor;
- (UISwitch *(^)(id))jh_onTintColor;
- (UISwitch *(^)(id))jh_thTintColor;
- (UISwitch *(^)(id))jh_onImage;
- (UISwitch *(^)(id))jh_offImage;

@end
