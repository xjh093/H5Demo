//
//  UITextView+JHCategory.m
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import "UITextView+JHCategory.h"
#import "UIView+JHCategory.h"
#import "UIFont+JHCategory.h"
#import "UIColor+JHCategory.h"
#import <objc/runtime.h>

@implementation UITextView (JHCategory)

+ (void)load{
    Method old = class_getInstanceMethod(self, @selector(setText:));
    Method new = class_getInstanceMethod(self, @selector(jh_setText:));
    method_exchangeImplementations(old, new);
}

- (void)jh_setText:(NSString *)text
{
    if ([text isKindOfClass:[NSNull class]]) {
        [self jh_setText:@""];
    }else{
        [self jh_setText:text];
    }
}

JH_new_m(UITextView)
JH_tag_m(UITextView)
JH_bind_m(UITextView)
JH_text_m(UITextView)
JH_font_m(UITextView)
JH_align_m(UITextView)
JH_color_m(UITextView)
JH_frame_m(UITextView)
JH_alpha_m(UITextView)
JH_bgColor_m(UITextView)
JH_bdColor_m(UITextView)
JH_bdWidth_m(UITextView)
JH_cnRadius_m(UITextView)
JH_mtBounds_m(UITextView)
JH_delegate_m(UITextView)
JH_addToView_m(UITextView)

@end
