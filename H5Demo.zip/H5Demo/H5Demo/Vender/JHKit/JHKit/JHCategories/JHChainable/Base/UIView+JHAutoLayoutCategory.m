//
//  UIView+JHAutoLayoutCategory.m
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import "UIView+JHAutoLayoutCategory.h"
#import "UIView+JHFrameLayout.h"

#import <objc/runtime.h>

#if __has_include(<JavaScriptCore/JavaScriptCore.h>)
#import <JavaScriptCore/JavaScriptCore.h>
#define JH_HAS_JSCore 1
#else
#define JH_HAS_JSCore 0
#endif

#if 0 //DEBUG
#define JHAutoLayoutLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__)
#else
#define JHAutoLayoutLog(...)
#endif

@implementation UIView (JHAutoLayoutCategory)

#pragma mark 添加收回键盘点击事件
- (void)jhAddKeyboardHiddenEvent{
    UITapGestureRecognizer *xTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboard)];
    [self addGestureRecognizer:xTap];
}

- (void)hideKeyboard{
    [self endEditing:YES];
}

#pragma mark 自动布局
- (void)jhAutoLayout
{
    
    //屏幕旋转通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(jhAutoLayoutSubview)
                                                 name:UIApplicationDidChangeStatusBarOrientationNotification
                                               object:nil];
    
    //view frame 更改通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(jhViewFrameChanged)
                                                 name:@"jhViewFrameChange"
                                               object:nil];
}

#pragma mark 当前window内view frame 有改动
- (void)jhViewFrameChanged
{
    if (self.subviews.count > 0) { //有子view
        for (UIView *view in self.subviews) {
            JHAutoLayoutLog(@"view tag:%@ - %p",@(view.tag),view);
            NSString *frameString = objc_getAssociatedObject(view, "jhFrameString");
            if (frameString.length > 0) {
                CGRect frame = [view jhRectFromString:frameString];
                if(!CGRectEqualToRect(CGRectZero, frame)) {
                    if (!CGRectEqualToRect(view.frame, frame)) {
                        view.frame = frame;
                    }
                    [view jhViewFrameChanged];
                }
            }
        }
    }
}

#pragma mark 布局子view
- (void)jhAutoLayoutSubview
{
    
    //当前视图不在窗口
    if (!self.window) {
        JHAutoLayoutLog(@"1");
        
        /**< 设置标志，view需要更新*/
        NSString *jh_rotate = objc_getAssociatedObject(self, "jhScreenRotateFlag");
        if ([jh_rotate isEqualToString:@"YES"]) {
            objc_setAssociatedObject(self, "jhScreenRotateFlag", @"NO", OBJC_ASSOCIATION_COPY_NONATOMIC);
            JHAutoLayoutLog(@"flag:NO");
        }else{
            objc_setAssociatedObject(self, "jhScreenRotateFlag", @"YES", OBJC_ASSOCIATION_COPY_NONATOMIC);
            JHAutoLayoutLog(@"flag:YES");
        }
        
        return;
    }
    if (self.subviews.count > 0) { //有子view
        for (UIView *view in self.subviews) {
            JHAutoLayoutLog(@"view tag:%@ - %p",@(view.tag),view);
            NSString *frameString = objc_getAssociatedObject(view, "jhFrameString");
            if (frameString.length > 0) {
                CGRect frame = [view jhRectFromString:frameString];
                if(!CGRectEqualToRect(CGRectZero, frame)) {
                    if (!CGRectEqualToRect(view.frame, frame)) {
                        view.frame = frame;
                    }
                    [view jhAutoLayoutSubview];
                }
            }
        }
    }
}

#pragma mark 更新布局
- (void)jhUpdateLayout
{
    /**< 控制器的view第一次加载的时候，就不用更新了*/
    BOOL jh_first_flag = [objc_getAssociatedObject(self, "jhFirstFlag") boolValue];
    /**< 屏幕是否有旋转过*/
    NSString *jh_rotate = objc_getAssociatedObject(self, "jhScreenRotateFlag");
    /**< 第一次加载，无旋转*/
    if (!jh_first_flag && !jh_rotate) {
        objc_setAssociatedObject(self, "jhFirstFlag", @(YES), OBJC_ASSOCIATION_ASSIGN);
    }else{
        
        /**< 屏幕有旋转过，才进行更新*/
        if ([jh_rotate isEqualToString:@"YES"]) {
            objc_setAssociatedObject(self, "jhScreenRotateFlag", @"NO", OBJC_ASSOCIATION_COPY_NONATOMIC);
            [UIView animateWithDuration:0.25 animations:^{
                [self jhAutoLayoutSubview];
                JHAutoLayoutLog(@"jhUpdateLayout");
            }];
        }
    }
}

#pragma mark 结束布局
- (void)jhEndLayout
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIApplicationDidChangeStatusBarOrientationNotification
                                                  object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:@"jhViewFrameChange"
                                                  object:nil];
}

#pragma mark 通过字符串转成frame & string -> frame
- (CGRect)jhRectFromString:(NSString *)frameStr
{
    NSString *saveFrameStr = frameStr;
    if ([frameStr hasPrefix:@"["] && [frameStr hasSuffix:@"]"] && frameStr.length > 3)
    {
        frameStr = [frameStr substringWithRange:NSMakeRange(1, frameStr.length - 2)];
        frameStr = [frameStr stringByReplacingOccurrencesOfString:@" " withString:@""];
        NSArray *xFourElementArr = [frameStr componentsSeparatedByString:@","];
        if (xFourElementArr.count != 4) return CGRectZero;
        
// 将计算好的 frame 绑定到 view 上，以免重复计算
// 优点：不用重复计算 frame
// 缺点：相关联的 view 的 frame 变动时，造成 frame 不能更新了
// 所以 不采用 绑定
#define kJHUSE_ASSOCIATED 0
#if kJHUSE_ASSOCIATED
        NSString *frameValue;
        const char *Landscape_Portrait;
        
        //横屏 & Landscape
        if ([[UIApplication sharedApplication] statusBarOrientation] == 3 ||
            [[UIApplication sharedApplication] statusBarOrientation] == 4) {
            //Landscape
            Landscape_Portrait = "jhFrameString_Landscape";
        }else{
            //Portrait
            Landscape_Portrait = "jhFrameString_Portrait";
        }
        
        //是否有绑定过 计算好的 frame
        frameValue = objc_getAssociatedObject(self, Landscape_Portrait);
        //NSLog(@"%s,frameVaue:%@",Landscape_Portrait,frameValue);
        if (frameValue) {
            return CGRectFromString(frameValue);
        }
#endif
        
        NSString *frameString = objc_getAssociatedObject(self, "jhFrameString");
        if (frameString.length == 0) {
            //首次关联对象
            objc_setAssociatedObject(self, "jhFrameString", saveFrameStr, OBJC_ASSOCIATION_COPY_NONATOMIC);
        }else if (frameString.length > 0 && ![saveFrameStr isEqualToString:frameString]){
            //更换关联对象
            objc_setAssociatedObject(self, "jhFrameString", saveFrameStr, OBJC_ASSOCIATION_COPY_NONATOMIC);
            
#if kJHUSE_ASSOCIATED
            //remove
            objc_setAssociatedObject(self, Landscape_Portrait, nil, OBJC_ASSOCIATION_COPY_NONATOMIC);
#endif
            
            //发个通知，重新布局
            [[NSNotificationCenter defaultCenter] postNotificationName:@"jhViewFrameChange" object:nil];
        }
        
        CGRect frame = CGRectZero;
        CGFloat W = [self jhFloatFromString:xFourElementArr[2]];
        frame.size.width = W;
        self.frame = frame;
        CGFloat H = [self jhFloatFromString:xFourElementArr[3]];
        frame.size.height = H;
        self.frame = frame;
        CGFloat X = [self jhFloatFromString:xFourElementArr[0]];
        frame.origin.x = X;
        self.frame = frame;
        CGFloat Y = [self jhFloatFromString:xFourElementArr[1]];
        frame.origin.y = Y;
        self.frame = frame;
        
#if kJHUSE_ASSOCIATED
        //
        objc_setAssociatedObject(self, Landscape_Portrait, NSStringFromCGRect(self.frame), OBJC_ASSOCIATION_COPY_NONATOMIC);
#endif
        
        return CGRectMake(X, Y, W, H);
    }
    
    return CGRectZero;
}

- (CGFloat)jhFloatFromString:(NSString *)string
{
    if ([string hasPrefix:@"x:"] ||
        [string hasPrefix:@"y:"] ||
        [string hasPrefix:@"w:"] ||
        [string hasPrefix:@"h:"])
    {
        NSString *subStr = [string substringFromIndex:2];
        
        //eg. maxx(100)+10 or midx(100)+10 x(100)+10 or x(100)
        
        //replace maxx(100) to CGRectGetMaxX(view.frame) //view.tag is 100
        //replace midx(100) to CGRectGetMidX(view.frame) //view.tag is 100
        //replace x(100)    to CGRectGetMinX(view.frame) //view.tag is 100
        
        while ([subStr rangeOfString:@")" options:NSBackwardsSearch].length > 0) {
            NSRange xRange = [subStr rangeOfString:@")" options:NSBackwardsSearch];
            NSString *leftPart = [subStr substringToIndex:xRange.location];
            xRange = [subStr rangeOfString:@"(" options:NSBackwardsSearch];
            if (xRange.length < 1) {
                break;
            }
            
            NSUInteger start = 0;
            for (NSInteger i = leftPart.length - 1; i >= 0; --i) {
                unichar c = [leftPart characterAtIndex:i];
                if (c == '+' || c == '-' || c == '*' || c == '/') {
                    start = i + 1;
                    break;
                }
            }
            
            NSString *rightPart = [leftPart substringFromIndex:start];
            CGFloat value = [self jhParseFirstSubStr:rightPart];
            NSString *replacePart = [NSString stringWithFormat:@"%.2f",value];
            
            NSRange range = [leftPart rangeOfString:rightPart];
            range.length += 1;
            subStr = [subStr stringByReplacingCharactersInRange:range withString:replacePart];
        }
        
        //replace W or H
        //W+10.0,W-10.0,W*10.0,W/10.0,W*200/320,
        //W - [UIScreen mainScreen].bounds.size.width
        //H - [UIScreen mainScreen].bounds.size.height
        //w - self.frame.size.width
        //h - self.frame.size.height
        if ([subStr containsString:@"W"] ||
            [subStr containsString:@"H"] ||
            [subStr containsString:@"w"] ||
            [subStr containsString:@"h"]) {
            CGFloat value = 0;
            NSRange range = NSMakeRange(0, 0);
            if ([subStr rangeOfString:@"W" options:NSLiteralSearch].length > 0) {
                range = [subStr rangeOfString:@"W" options:NSLiteralSearch];
                value = [UIScreen mainScreen].bounds.size.width;
                
                subStr = [self jhReplace:value :subStr :range];
            }
            if ([subStr rangeOfString:@"H" options:NSLiteralSearch].length > 0){
                range = [subStr rangeOfString:@"H" options:NSLiteralSearch];
                value = [UIScreen mainScreen].bounds.size.height;
                
                subStr = [self jhReplace:value :subStr :range];
            }
            if ([subStr rangeOfString:@"w" options:NSLiteralSearch].length > 0) {
                range = [subStr rangeOfString:@"w" options:NSLiteralSearch];
                value = self.frame.size.width;
                
                subStr = [self jhReplace:value :subStr :range];
            }
            if ([subStr rangeOfString:@"h" options:NSLiteralSearch].length > 0){
                range = [subStr rangeOfString:@"h" options:NSLiteralSearch];
                value = self.frame.size.height;
                
                subStr = [self jhReplace:value :subStr :range];
            }
        }
        
        if ([subStr containsString:@"+"] ||
            [subStr containsString:@"-"] ||
            [subStr containsString:@"*"] ||
            [subStr containsString:@"/"] ) {
            if (JH_HAS_JSCore) {
                //NSLog(@"JH_HAS_JSCore YES");
                JSContext *context = [[JSContext alloc] init];
                JSValue *value = [context evaluateScript:subStr];
                return (CGFloat)[value toDouble];
            }else{
                //NSLog(@"JH_HAS_JSCore NO");
                return [[NSString jh_caculateStringFormula:subStr] floatValue];
            }
        }
        else if ([self isPureInt:subStr] || [self isPureFloat:subStr]) {
            return [subStr floatValue];
        }else{
            return 0.0;
        }
    }
    return 0.0;
}

- (NSString *)jhReplace:(CGFloat)value :(NSString *)subStr :(NSRange)range
{
    NSString *replaceString = [NSString stringWithFormat:@"%.2f",value];
    return [subStr stringByReplacingOccurrencesOfString:[subStr substringWithRange:range] withString:replaceString];
}

#pragma mark 是否为整形
- (BOOL)isPureInt:(NSString*)string
{
    NSScanner *scan = [NSScanner scannerWithString:string];
    int val;
    return [scan scanInt:&val] && [scan isAtEnd];
}

#pragma mark 是否为浮点形
- (BOOL)isPureFloat:(NSString*)string
{
    NSScanner *scan = [NSScanner scannerWithString:string];
    float val;
    return [scan scanFloat:&val] && [scan isAtEnd];
}

- (CGFloat)jhParseFirstSubStr:(NSString *)firstStr
{
    NSArray *subArr = [firstStr componentsSeparatedByString:@"("];
    if (subArr.count != 2) return 0.0;
    
    NSString *first  = subArr[0];
    NSString *second = subArr[1];
    
    if (![self isPureInt:second]) return 0.0;
    
    UIView *view = [[self topSuperView] viewWithTag:[second integerValue]];
    if (view == nil) {
        view = [self viewWithTag:[second integerValue]];
        if (view == nil) {
            return 0.0;
        }
    }
    
    return [self jhFloatFromView:view withPreID:first];
}

- (CGFloat)jhFloatFromView:(UIView *)view withPreID:(NSString *)first
{
    if ([first isEqualToString:@"x"]) {
        return CGRectGetMinX(view.frame);
    }else if ([first isEqualToString:@"y"]){
        return CGRectGetMinY(view.frame);
    }else if ([first isEqualToString:@"w"]){
        return CGRectGetWidth(view.frame);
    }else if ([first isEqualToString:@"h"]){
        return CGRectGetHeight(view.frame);
    }else if ([first isEqualToString:@"maxx"]){
        return CGRectGetMaxX(view.frame);
    }else if ([first isEqualToString:@"maxy"]){
        return CGRectGetMaxY(view.frame);
    }else if ([first isEqualToString:@"midx"]){
        return CGRectGetMidX(view.frame);
    }else if ([first isEqualToString:@"midy"]){
        return CGRectGetMidY(view.frame);
    }else{
        return [self jhMultiple:first view:view];
    }
    return 0.0;
}

- (CGFloat)jhMultiple:(NSString *)prefix view:(UIView *)view
{
    /**< prefix: eg: 2_x,3_x,4_x,...*/
    if ([prefix rangeOfString:@"_"].length == 0) {
        return 0.0;
    }
    
    NSArray *arr = [prefix componentsSeparatedByString:@"_"];
    NSString *first = arr[0];
    if (![self isPureInt:first]) return 0.0;
    
    CGFloat floatValue = [self jhFloatFromView:view withPreID:arr[1]];
    return floatValue/[first integerValue];
}

- (CGSize)jhSizeFromString:(NSString *)sizeStr
{
    if ([sizeStr hasPrefix:@"["] && [sizeStr hasSuffix:@"]"] && sizeStr.length > 3)
    {
        sizeStr = [sizeStr substringWithRange:NSMakeRange(1, sizeStr.length - 2)];
        sizeStr = [sizeStr stringByReplacingOccurrencesOfString:@" " withString:@""];
        NSArray *xTwoElementArr = [sizeStr componentsSeparatedByString:@","];
        if (xTwoElementArr.count != 2) return CGSizeZero;
        
        CGFloat X = [self jhFloatFromString:xTwoElementArr[0]];
        CGFloat Y = [self jhFloatFromString:xTwoElementArr[1]];
        
        return CGSizeMake(X, Y);
    }
    
    return CGSizeZero;
}

#pragma mark --- frameDic -> frame

/*
 {
 top:[is:10],
 
 left:[is:10],
 
 right:[is:10],
 
 bottom:[is:10],
 
 top:[is:10,from:left,ofview:0,update:0],
 
 left:[is:10,from:top,ofview:0,update:0],
 
 right:[is:-10,from:right,ofview:0,update:1],
 
 bottom:[is:-10,from:bottom,ofview:0,update:1],
 
 centerX:[is:0,from:middle,ofview:0,update:0],
 
 centerY:[is:0,from:middle,ofview:0,update:0],
 
 width:[is:10],
 
 height:[is:10],
 
 width:[is:10 ofview:0 ratio:w],
 
 width:[is:10 ofview:0 ratio:h],
 
 height:[is:10 ofview:0 ratio:w],
 
 height:[is:10 ofview:0 ratio:h],
 
 }
 */

- (CGRect)jhRectFromArray:(NSArray *)frameArr
{
    if (frameArr.count == 0) {
        return CGRectZero;
    }
    
    NSArray *array = [frameArr copy];
    
    for (int i = 0; i < array.count; ++i) {
        NSString *key = [array[i] allKeys][0];
        NSDictionary *value = [array[i] allValues][0];
        
        // top
        if ([key isEqualToString:@"top"]) {
            
            if (value.count == 1 && [value.allKeys[0] isEqualToString:@"is"]) {
                [self jh_topIs:[value[@"is"] floatValue]];
                continue;
            }
            
            if (value.count == 4) {
                CGFloat   offsetY  = [value[@"is"] floatValue];
                NSString *position = value[@"from"];
                NSInteger viewTag  = [value[@"ofview"] integerValue];
                BOOL      flag     = [value[@"update"] boolValue];
                
                if ([position isEqualToString:@"top"]) {
                    [self jh_topIs:offsetY fromTopOfView:[[self topSuperView] viewWithTag:viewTag] updateHeight:flag];
                }else if ([position isEqualToString:@"middle"]){
                    [self jh_topIs:offsetY fromMiddleOfView:[[self topSuperView] viewWithTag:viewTag] updateHeight:flag];
                }else if ([position isEqualToString:@"bottom"]){
                    [self jh_topIs:offsetY fromBottomOfView:[[self topSuperView] viewWithTag:viewTag] updateHeight:flag];
                }
            }
        }
        
        // left
        else if ([key isEqualToString:@"left"]) {
            
            if (value.count == 1 && [value.allKeys[0] isEqualToString:@"is"]) {
                [self jh_leftIs:[value[@"is"] floatValue]];
                continue;
            }
            
            if (value.count == 4) {
                CGFloat   offsetX  = [value[@"is"] floatValue];
                NSString *position = value[@"from"];
                NSInteger viewTag  = [value[@"ofview"] integerValue];
                BOOL      flag     = [value[@"update"] boolValue];
                
                if ([position isEqualToString:@"left"]) {
                    [self jh_leftIs:offsetX fromLeftOfView:[[self topSuperView] viewWithTag:viewTag] updateWidth:flag];
                }else if ([position isEqualToString:@"middle"]){
                    [self jh_leftIs:offsetX fromMiddleOfView:[[self topSuperView] viewWithTag:viewTag] updateWidth:flag];
                }else if ([position isEqualToString:@"right"]){
                    [self jh_leftIs:offsetX fromRightOfView:[[self topSuperView] viewWithTag:viewTag] updateWidth:flag];
                }
            }
        }
        
        // bottom
        else if ([key isEqualToString:@"bottom"]) {
            
            if (value.count == 1 && [value.allKeys[0] isEqualToString:@"is"]) {
                [self jh_bottomIs:[value[@"is"] floatValue]];
                continue;
            }
            
            if (value.count == 4) {
                CGFloat   offsetY  = [value[@"is"] floatValue];
                NSString *position = value[@"from"];
                NSInteger viewTag  = [value[@"ofview"] integerValue];
                BOOL      flag     = [value[@"update"] boolValue];
                
                if ([position isEqualToString:@"top"]) {
                    [self jh_bottomIs:offsetY fromTopOfView:[[self topSuperView] viewWithTag:viewTag] updateHeight:flag];
                }else if ([position isEqualToString:@"middle"]){
                    [self jh_bottomIs:offsetY fromMiddleOfView:[[self topSuperView] viewWithTag:viewTag] updateHeight:flag];
                }else if ([position isEqualToString:@"bottom"]){
                    [self jh_bottomIs:offsetY fromBottomOfView:[[self topSuperView] viewWithTag:viewTag] updateHeight:flag];
                }
            }
        }
        // right
        else if ([key isEqualToString:@"right"]) {
            
            if (value.count == 1 && [value.allKeys[0] isEqualToString:@"is"]) {
                [self jh_rightIs:[value[@"is"] floatValue]];
                continue;
            }
            
            if (value.count == 4) {
                CGFloat   offsetX  = [value[@"is"] floatValue];
                NSString *position = value[@"from"];
                NSInteger viewTag  = [value[@"ofview"] integerValue];
                BOOL      flag     = [value[@"update"] boolValue];
                
                if ([position isEqualToString:@"left"]) {
                    [self jh_rightIs:offsetX fromLeftOfView:[[self topSuperView] viewWithTag:viewTag] updateWidth:flag];
                }else if ([position isEqualToString:@"middle"]){
                    [self jh_rightIs:offsetX fromMiddleOfView:[[self topSuperView] viewWithTag:viewTag] updateWidth:flag];
                }else if ([position isEqualToString:@"right"]){
                    [self jh_rightIs:offsetX fromRightOfView:[[self topSuperView] viewWithTag:viewTag] updateWidth:flag];
                }
            }
        }
        // centerX
        else if ([key isEqualToString:@"centerX"]) {
            
            if (value.count == 1 && [value.allKeys[0] isEqualToString:@"is"]) {
                [self jh_centerXIs:[value[@"is"] floatValue]];
                continue;
            }
            
            if (value.count == 4) {
                CGFloat   offsetX  = [value[@"is"] floatValue];
                NSString *position = value[@"from"];
                NSInteger viewTag  = [value[@"ofview"] integerValue];
                BOOL      flag     = [value[@"update"] boolValue];
                
                if ([position isEqualToString:@"left"]) {
                    [self jh_centerXIs:offsetX fromLeftOfView:[[self topSuperView] viewWithTag:viewTag] updateWidth:flag];
                }else if ([position isEqualToString:@"middle"]){
                    [self jh_centerXIs:offsetX fromMiddleOfView:[[self topSuperView] viewWithTag:viewTag] updateWidth:flag];
                }else if ([position isEqualToString:@"right"]){
                    [self jh_centerXIs:offsetX fromRightOfView:[[self topSuperView] viewWithTag:viewTag] updateWidth:flag];
                }
            }
        }
        // centerY
        else if ([key isEqualToString:@"centerY"]) {
            
            if (value.count == 1 && [value.allKeys[0] isEqualToString:@"is"]) {
                [self jh_centerYIs:[value[@"is"] floatValue]];
                continue;
            }
            
            if (value.count == 4) {
                CGFloat   offsetY  = [value[@"is"] floatValue];
                NSString *position = value[@"from"];
                NSInteger viewTag  = [value[@"ofview"] integerValue];
                BOOL      flag     = [value[@"update"] boolValue];
                
                if ([position isEqualToString:@"top"]) {
                    [self jh_centerYIs:offsetY fromTopOfView:[[self topSuperView] viewWithTag:viewTag] updateHeight:flag];
                }else if ([position isEqualToString:@"middle"]){
                    [self jh_centerYIs:offsetY fromMiddleOfView:[[self topSuperView] viewWithTag:viewTag] updateHeight:flag];
                }else if ([position isEqualToString:@"bottom"]){
                    [self jh_centerYIs:offsetY fromBottomOfView:[[self topSuperView] viewWithTag:viewTag] updateHeight:flag];
                }
            }
        }
        // width
        else if ([key isEqualToString:@"width"]) {
            
            if (value.count == 1 && [value.allKeys[0] isEqualToString:@"is"]) {
                [self jh_widthIs:[value[@"is"] floatValue]];
                continue;
            }
            
            if (value.count == 3) {
                CGFloat   valuef  = [value[@"is"] floatValue];
                NSInteger viewTag = [value[@"ofview"] integerValue];
                NSString *ratio   = value[@"ratio"];
                
                if ([ratio isEqualToString:@"w"]) {
                    [self jh_widthIs:valuef ratioOfViewWidth:[[self topSuperView] viewWithTag:viewTag]];
                }else if ([ratio isEqualToString:@"h"]) {
                    [self jh_widthIs:valuef ratioOfViewHeight:[[self topSuperView] viewWithTag:viewTag]];
                }
            }
            
        }
        // height
        else if ([key isEqualToString:@"height"]) {
            
            if (value.count == 1 && [value.allKeys[0] isEqualToString:@"is"]) {
                [self jh_heightIs:[value[@"is"] floatValue]];
                continue;
            }
            
            if (value.count == 3) {
                CGFloat   valuef  = [value[@"is"] floatValue];
                NSInteger viewTag = [value[@"ofview"] integerValue];
                NSString *ratio   = value[@"ratio"];
                
                if ([ratio isEqualToString:@"w"]) {
                    [self jh_heightIs:valuef ratioOfViewWidth:[[self topSuperView] viewWithTag:viewTag]];
                }else if ([ratio isEqualToString:@"h"]) {
                    [self jh_heightIs:valuef ratioOfViewHeight:[[self topSuperView] viewWithTag:viewTag]];
                }
            }
        }
    }
    
    return self.frame;
}

- (UIView *)topSuperView
{
    UIView *topSuperView = self;
    while (topSuperView.superview) {
        topSuperView = topSuperView.superview;
    }
    return topSuperView;
}

@end
