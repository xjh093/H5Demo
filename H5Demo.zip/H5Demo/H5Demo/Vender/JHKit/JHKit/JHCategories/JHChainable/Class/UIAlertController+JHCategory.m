//
//  UIAlertController+JHCategory.m
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import "UIAlertController+JHCategory.h"

@implementation UIAlertController (JHCategory)

+ (UIAlertController *(^)(id,id,id))jh_alertCtrl{
    return ^id(id title,id message,id type){
        if ([type integerValue] == 0 || [type integerValue] == 1) {
            UIAlertController *jhAlert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:[type integerValue]];
            return jhAlert;
        }
        return nil;
    };
}

- (UIAlertController *(^)(id,jhAlertAction))jh_addNormalAction{
    return ^id(id title,jhAlertAction jhBlock){
        UIAlertAction *jhAction = [UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            if (jhBlock) {
                jhBlock();
            }
        }];
        [self addAction:jhAction];
        return self;
    };
}

- (UIAlertController *(^)(id,jhAlertAction))jh_addCancelAction{
    return ^id(id title,jhAlertAction jhBlock){
        UIAlertAction *jhAction = [UIAlertAction actionWithTitle:title style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            if (jhBlock) {
                jhBlock();
            }
        }];
        [self addAction:jhAction];
        return self;
    };
}

- (UIAlertController *(^)(id,jhAlertAction))jh_addDestructAction{
    return ^id(id title,jhAlertAction jhBlock){
        UIAlertAction *jhAction = [UIAlertAction actionWithTitle:title style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            if (jhBlock) {
                jhBlock();
            }
        }];
        [self addAction:jhAction];
        return self;
    };
}

- (UIAlertController *(^)(id))jh_addTextField{
    return ^id(id title){
        [self addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            textField.placeholder = title;
            textField.leftViewMode = UITextFieldViewModeAlways;
            textField.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 8, 8)];
        }];
        return self;
    };
}

- (UIAlertController *(^)(id))jh_show{
    return ^id(id vc){
        if ([vc isKindOfClass:[UIViewController class]]) {
            [vc presentViewController:self animated:YES completion:nil];
        }
        return self;
    };
}

@end
