//
//  UITextField+JHCategory.h
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import <UIKit/UIKit.h>
#import "JHCategoriesDeifne.h"

#define jhTextField() jh_new()

@interface UITextField (JHCategory)

JH_new_h(UITextField)
JH_tag_h(UITextField)
JH_bind_h(UITextField)
JH_text_h(UITextField)
JH_font_h(UITextField)
JH_align_h(UITextField)
JH_color_h(UITextField)
JH_frame_h(UITextField)
JH_alpha_h(UITextField)
JH_bgColor_h(UITextField)
JH_bdColor_h(UITextField)
JH_bdWidth_h(UITextField)
JH_cnRadius_h(UITextField)
JH_mtBounds_h(UITextField)
JH_delegate_h(UITextField)
JH_addToView_h(UITextField)

- (UITextField *(^)(id))jh_bdStyle;
- (UITextField *(^)(id))jh_pHolder;
- (UITextField *(^)(id))jh_pHColor;
- (UITextField *(^)(id))jh_pHFont;
- (UITextField *(^)(id))jh_cbMode;
- (UITextField *(^)(id))jh_lvMode;
- (UITextField *(^)(id))jh_rvMode;
- (UITextField *(^)(id))jh_lfView;
- (UITextField *(^)(id))jh_rtView;
- (UITextField *(^)(id))jh_secure;

@end
