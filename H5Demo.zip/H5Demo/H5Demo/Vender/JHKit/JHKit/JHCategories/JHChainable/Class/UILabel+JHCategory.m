//
//  UILabel+JHCategory.m
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import "UILabel+JHCategory.h"
#import "UIView+JHCategory.h"
#import "UIFont+JHCategory.h"
#import "UIColor+JHCategory.h"
#import <objc/runtime.h>

@implementation UILabel (JHCategory)

+ (void)load{
    Method old = class_getInstanceMethod(self, @selector(setText:));
    Method new = class_getInstanceMethod(self, @selector(jh_setText:));
    method_exchangeImplementations(old, new);
}

- (void)jh_setText:(NSString *)text
{
    if ([text isKindOfClass:[NSNull class]]) {
        [self jh_setText:@""];
    }else{
        [self jh_setText:text];
    }
}

JH_new_m(UILabel)
JH_tag_m(UILabel)
JH_bind_m(UILabel)
JH_text_m(UILabel)
JH_font_m(UILabel)
JH_align_m(UILabel)
JH_color_m(UILabel)
JH_frame_m(UILabel)
JH_alpha_m(UILabel)
JH_bgColor_m(UILabel)
JH_bdColor_m(UILabel)
JH_bdWidth_m(UILabel)
JH_cnRadius_m(UILabel)
JH_mtBounds_m(UILabel)
JH_addToView_m(UILabel)

- (UILabel *(^)(id))jh_lines{
    JHLog();
    return ^id(id lines){
        if ([lines isKindOfClass:[NSNumber class]]) {
            self.numberOfLines = [lines integerValue];
        }
        return self;
    };
}

- (UILabel *(^)(id))jh_adjust{
    JHLog();
    return ^id(id adjust){
        if ([adjust isKindOfClass:[NSNumber class]]) {
            self.adjustsFontSizeToFitWidth = [adjust boolValue];
        }
        return self;
    };
}

- (UILabel *(^)(id))jh_autoWidth{
    JHLog();
    return ^id(id maxWidth){
        if (self.text.length == 0) {
            NSLog(@"%s,text length is 0",__FUNCTION__);
            return self;
        }
        
        CGRect frame = self.frame;
        self.numberOfLines = 1;
        [self sizeToFit];
        
        if ([maxWidth floatValue] > 0 &&
            self.frame.size.width > [maxWidth floatValue])
        {
            frame.size.width = [maxWidth floatValue];
        }else{
            frame.size.width = self.frame.size.width;
        }
        self.frame = frame;
        return self;
    };
}

- (UILabel *(^)(id))jh_autoHeight{
    JHLog();
    return ^id(id maxHeight){
        if (self.text.length == 0) {
            NSLog(@"%s,text length is 0",__FUNCTION__);
            return self;
        }
        
        CGRect frame = self.frame;
        self.numberOfLines = 0;
        [self sizeToFit];
        
        if ([maxHeight floatValue] > 0 &&
            self.frame.size.width > [maxHeight floatValue]) {
            frame.size.height = [maxHeight floatValue];
        }else{
            frame.size.height = self.frame.size.height;
        }
        self.frame = frame;
        return self;
    };
}

- (void)jhLabelFrame:(id)frame text:(NSString *)text color:(id)color font:(id)font align:(CGFloat)align
{
    self.jh_frame(({
        NSString *frameString = @"";
        if ([frame isKindOfClass:[NSString class]]) {
            frameString = frame;
        }else if ([frame isKindOfClass:[NSValue class]]){
            frameString = NSStringFromCGRect([frame CGRectValue]);
        }
        frameString;
    }))
    .jh_text(text)
    .jh_color([UIColor jhColor:color])
    .jh_font([UIFont jhFont:font])
    .jh_align(@(align));
}

- (void)jhAddAttributeWithSubString:(NSString *)string value:(id)value
{
    //颜色
    if ([value isKindOfClass:[UIColor class]]) {
        NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc] initWithAttributedString:self.attributedText];
        [attStr addAttribute:NSForegroundColorAttributeName value:value range:[self.text rangeOfString:string]];
        self.attributedText = attStr;
    }
    //字体
    else if ([value isKindOfClass:[UIFont class]]){
        NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc] initWithAttributedString:self.attributedText];
        [attStr addAttribute:NSFontAttributeName value:value range:[self.text rangeOfString:string]];
        self.attributedText = attStr;
    }
}
- (void)jhAddAttributeWithSubString:(NSString *)string value:(id)value range:(NSRange)range
{
    //颜色
    if ([value isKindOfClass:[UIColor class]]) {
        NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc] initWithAttributedString:self.attributedText];
        [attStr addAttribute:NSForegroundColorAttributeName value:value range:range];
        self.attributedText = attStr;
    }
    //字体
    else if ([value isKindOfClass:[UIFont class]]){
        NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc] initWithAttributedString:self.attributedText];
        [attStr addAttribute:NSFontAttributeName value:value range:range];
        self.attributedText = attStr;
    }
}
- (void)jhAddLineSpace:(CGFloat)space{
    NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc] initWithAttributedString:self.attributedText];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:space < 0 ? 0 : space];
    paragraphStyle.alignment = self.textAlignment;
    [attStr addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [self.text length])];
    self.attributedText = attStr;
}
@end
