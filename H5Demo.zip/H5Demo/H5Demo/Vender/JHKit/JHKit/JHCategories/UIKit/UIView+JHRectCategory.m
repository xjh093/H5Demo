//
//  UIView+JHRectCategory.m
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import "UIView+JHRectCategory.h"

@implementation UIView (JHRectCategory)

- (void)setJh_x:(CGFloat)jh_x{
    CGRect frame = self.frame;
    frame.origin.x = jh_x;
    self.frame = frame;
}

- (CGFloat)jh_x{
    return self.frame.origin.x;
}

- (void)setJh_y:(CGFloat)jh_y{
    CGRect frame = self.frame;
    frame.origin.y = jh_y;
    self.frame = frame;
}

- (CGFloat)jh_y{
    return self.frame.origin.y;
}

- (void)setJh_w:(CGFloat)jh_w{
    CGRect frame = self.frame;
    frame.size.width = jh_w;
    self.frame = frame;
}

- (CGFloat)jh_w{
    return self.frame.size.width;
}

- (void)setJh_h:(CGFloat)jh_h{
    CGRect frame = self.frame;
    frame.size.height = jh_h;
    self.frame = frame;
}

- (CGFloat)jh_h{
    return self.frame.size.height;
}

- (void)setJh_center_x:(CGFloat)jh_center_x{
    CGPoint point = self.center;
    point.x = jh_center_x;
    self.center = point;
}

- (CGFloat)jh_center_x{
    return self.center.x;
}

- (void)setJh_center_y:(CGFloat)jh_center_y{
    CGPoint point = self.center;
    point.y = jh_center_y;
    self.center = point;
}

- (CGFloat)jh_center_y{
    return self.center.y;
}

- (void)setJh_origin:(CGPoint)jh_origin{
    CGRect frame = self.frame;
    frame.origin.x = jh_origin.x;
    frame.origin.y = jh_origin.y;
    self.frame = frame;
}

- (CGPoint)jh_origin{
    return self.frame.origin;
}

- (void)setJh_size:(CGSize)jh_size{
    CGRect frame = self.frame;
    frame.size.width  = jh_size.width;
    frame.size.height = jh_size.height;
    self.frame = frame;
}

- (CGSize)jh_size{
    return self.frame.size;
}

- (void)setJh_mid_x:(CGFloat)jh_mid_x{
    self.jh_x = jh_mid_x - self.jh_w*0.5;
}

- (CGFloat)jh_mid_x{
    return CGRectGetMidX(self.frame);
}

- (void)setJh_mid_y:(CGFloat)jh_mid_y{
    self.jh_y = jh_mid_y - self.jh_h*0.5;
}

- (CGFloat)jh_mid_y{
    return CGRectGetMidY(self.frame);
}

- (void)setJh_max_x:(CGFloat)jh_max_x{
    self.jh_x = jh_max_x - self.jh_w;
}

- (CGFloat)jh_max_x{
    return CGRectGetMaxX(self.frame);
}

- (void)setJh_max_y:(CGFloat)jh_max_y{
    self.jh_y = jh_max_y - self.jh_h;
}

- (CGFloat)jh_max_y{
    return CGRectGetMaxY(self.frame);
}

@end
