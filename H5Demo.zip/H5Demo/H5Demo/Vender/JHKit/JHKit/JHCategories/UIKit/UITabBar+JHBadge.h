//
//  UITabBar+JHBadge.h
//  JHKit
//
//  Created by xuejinghao on 2018/4/12.
//  Copyright © 2018年 HaoCold. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITabBar (JHBadge)

/// Show red dot.
- (void)jh_showRedDot:(NSInteger)index;

/// Hide red dot.
- (void)jh_hideRedDot:(NSInteger)index;

@end
