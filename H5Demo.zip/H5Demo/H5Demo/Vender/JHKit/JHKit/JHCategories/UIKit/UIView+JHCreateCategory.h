//
//  UIView+JHCreateCategory.h
//
//  Created by Lightech on 14/12/2.
//  Copyright © 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#if 0

#import <UIKit/UIKit.h>

#define JH_CREATE_CLASS_h(jhclass) \
+ (jhclass *)jhCreate##jhclass##WithDic:(NSDictionary *)paraDic \
                              superView:(UIView *)superView;

#define JH_UPDATE_CLASS_h(jhclass) \
+ (void)jhUpdate##jhclass:(jhclass *)x##jhclass \
                  paraDic:(NSDictionary *)paraDic \
                superView:(UIView *)superView;

@interface UIView (JHCreateCategory)
JH_CREATE_CLASS_h(UIView)
JH_UPDATE_CLASS_h(UIView)
@end

@interface UILabel (JHCreateCategory)
JH_CREATE_CLASS_h(UILabel)
JH_UPDATE_CLASS_h(UILabel)
@end

@interface UIButton (JHCreateCategory)
JH_CREATE_CLASS_h(UIButton)
JH_UPDATE_CLASS_h(UIButton)
@end

@interface UIScrollView (JHCreateCategory)
JH_CREATE_CLASS_h(UIScrollView)
JH_UPDATE_CLASS_h(UIScrollView)
@end

@interface UITableView (JHCreateCategory)
JH_CREATE_CLASS_h(UITableView)
JH_UPDATE_CLASS_h(UITableView)
@end

@interface UITextField (JHCreateCategory)
JH_CREATE_CLASS_h(UITextField)
JH_UPDATE_CLASS_h(UITextField)
@end

@interface UITextView (JHCreateCategory)
JH_CREATE_CLASS_h(UITextView)
JH_UPDATE_CLASS_h(UITextView)
@end

@interface UISwitch (JHCreateCategory)
JH_CREATE_CLASS_h(UISwitch)
JH_UPDATE_CLASS_h(UISwitch)
@end

@interface UIImageView (JHCreateCategory)
JH_CREATE_CLASS_h(UIImageView)
JH_UPDATE_CLASS_h(UIImageView)
@end

@interface UISlider (JHCreateCategory)
JH_CREATE_CLASS_h(UISlider)
JH_UPDATE_CLASS_h(UISlider)
@end

@interface UIStepper (JHCreateCategory)
JH_CREATE_CLASS_h(UIStepper)
JH_UPDATE_CLASS_h(UIStepper)
@end

@interface UISegmentedControl (JHCreateCategory)
JH_CREATE_CLASS_h(UISegmentedControl)
JH_UPDATE_CLASS_h(UISegmentedControl)

@end

#endif

