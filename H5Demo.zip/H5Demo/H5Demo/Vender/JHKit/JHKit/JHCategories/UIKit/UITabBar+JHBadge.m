//
//  UITabBar+JHBadge.m
//  JHKit
//
//  Created by xuejinghao on 2018/4/12.
//  Copyright © 2018年 HaoCold. All rights reserved.
//

#import "UITabBar+JHBadge.h"

@implementation UITabBar (JHBadge)

- (void)jh_showRedDot:(NSInteger)index{
    [[self reddotForIndex:index] setHidden:NO];
}

- (void)jh_hideRedDot:(NSInteger)index{
    [[self reddotForIndex:index] setHidden:YES];
}

#pragma mark - private
- (UIView *)reddotForIndex:(NSInteger)index
{
    NSInteger tag = 666 + index;
    UIView *reddot = [self viewWithTag:tag];
    if (!reddot) {
        
        // If add custom button in 'Tabbar', 'count' should +1.
        // 如果添加了自定义按钮，这里应该 +1.
        NSInteger count = self.items.count;
        CGFloat X = CGRectGetWidth(self.bounds)*((index+0.65)/count);
        CGFloat Y = CGRectGetHeight(self.bounds)*0.1;
        UIView *view = [[UIView alloc] init];
        view.backgroundColor = [UIColor redColor];
        view.layer.cornerRadius = 5;
        view.tag = tag;
        view.frame = CGRectMake(X, Y, 10, 10);
        [self addSubview:view];
        reddot = view;
    }
    return reddot;
}

@end
