//
//  UIView+JHCreateCategory.m
//
//  Created by Lightech on 14/12/2.
//  Copyright © 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#if 0

#import "UIView+JHCreateCategory.h"
#import "UIFont+JHCategory.h"
#import "UIColor+JHCategory.h"
#import "UIView+JHAutoLayoutCategory.h"

#define JH_CREATE_CLASS_m(jhclass) \
+ (jhclass *)jhCreate##jhclass##WithDic:(NSDictionary *)paraDic superView:(UIView *)superView{ \
    jhclass *x##jhclass = [[jhclass alloc] init]; \
    if (superView) { \
        [superView addSubview:x##jhclass]; \
    } \
    [self jhUpdate##jhclass:x##jhclass paraDic:paraDic superView:superView]; \
    return x##jhclass;\
}

@interface NSObject (PerformSelector)
-(id)performSelector:(SEL)Selector withObjects:(NSArray *)objects;
@end

@implementation NSObject (PerformSelector)
-(id)performSelector:(SEL)selector withObjects:(NSArray *)objects{
    
    NSMethodSignature *signature = [[self class] instanceMethodSignatureForSelector:selector];
    
    if(signature == nil){
        
        NSString *reason = [NSString stringWithFormat:@"%@方法不存在",NSStringFromSelector(selector)];
        
        @throw [NSException exceptionWithName:@"error" reason:reason userInfo:nil];
    }
    
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
    
    invocation.target = self;
    
    invocation.selector = selector;
    
    //参数个数 默认有一个_cmd 一个target 所以要-2
    NSInteger paramsCount = signature.numberOfArguments - 2;
    
    // 当objects的个数多于函数的参数的时候,取前面的参数
    // 当objects的个数少于函数的参数的时候,不需要设置,默认为nil
    paramsCount = MIN(paramsCount, objects.count);
    
    for (NSInteger index = 0; index < paramsCount; index++) {
        
        id object = objects[index];
        
        if([object isKindOfClass:[NSNull class]]) continue;
        
        [invocation setArgument:&object atIndex:index+2];
        
    }

    [invocation invoke];

    id returnValue = nil;
    
    if (signature.methodReturnLength) {
        
        [invocation getReturnValue:&returnValue];
    }
    
    return returnValue;
}
@end

#pragma mark -
@implementation UIView (JHCreateCategory)

JH_CREATE_CLASS_m(UIView)

+ (void)jhUpdateUIView:(UIView *)xUIView
               paraDic:(NSDictionary *)paraDic
             superView:(UIView *)superView{
    NSMutableDictionary *mdic = [paraDic mutableCopy];
    [mdic setValue:[UIColor jhColor:mdic[@"backgroundColor"]] forKey:@"backgroundColor"];
    [mdic setValue:[NSValue valueWithCGRect:CGRectFromString(mdic[@"frame"])] forKey:@"frame"];
    paraDic = mdic;
    
    for (NSString *key in paraDic.allKeys) {
        if ([key containsString:@"."]) {
            [xUIView setValue:paraDic[key] forKeyPath:key];
        }else{
            [xUIView setValue:paraDic[key] forKey:key];
        }
    }
    if (paraDic[@"layer.borderColor"]) {
        xUIView.layer.borderColor = [paraDic[@"layer.borderColor"] CGColor];
    }
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{}

@end


#pragma mark -
@implementation UILabel (JHCreateCategory)

JH_CREATE_CLASS_m(UILabel)

+ (void)jhUpdateUILabel:(UILabel *)xLabel
                paraDic:(NSDictionary *)paraDic
              superView:(UIView *)superView{
    if (paraDic[@"layer.borderColor"]) {
        xLabel.layer.borderColor = [paraDic[@"layer.borderColor"] CGColor];
    }
    for (NSString *key in paraDic.allKeys) {
        if ([key containsString:@"."]) {
            [xLabel setValue:paraDic[key] forKeyPath:key];
        }else{
            [xLabel setValue:paraDic[key] forKey:key];
        }
    }
}

@end

#if 0
#pragma mark -
@implementation UIButton (JHCreateCategory)

JH_CREATE_CLASS_m(UIButton)

+ (void)jhUpdateUIButton:(UIButton *)xButton
                 paraDic:(NSDictionary *)paraDic
               superView:(UIView *)superView
{
    [self jhUpdateUIView:xButton paraDic:paraDic superView:superView];
    
    if (paraDic[kJHTitleKey]) {
        [xButton setTitle:paraDic[kJHTitleKey] forState:UIControlStateNormal];
    }
    if (paraDic[kJHTitleColorKey]) {
        [xButton setTitleColor:[UIColor jhColorWithObject:paraDic[kJHTitleColorKey]] forState:UIControlStateNormal];
    }
    if (paraDic[kJHHighlightedTitleKey]) {
        [xButton setTitle:paraDic[kJHHighlightedTitleKey] forState:UIControlStateHighlighted];
    }
    if (paraDic[kJHHighlightedTitleColorKey]) {
        [xButton setTitleColor:[UIColor jhColorWithObject:paraDic[kJHHighlightedTitleColorKey]] forState:UIControlStateHighlighted];
    }
    if (paraDic[kJHSelectedTitleKey]) {
        [xButton setTitle:paraDic[kJHSelectedTitleKey] forState:UIControlStateSelected];
    }
    if (paraDic[kJHSelectedTitleColorKey]) {
        [xButton setTitleColor:[UIColor jhColorWithObject:paraDic[kJHSelectedTitleColorKey]] forState:UIControlStateSelected];
    }
    if (paraDic[kJHFontKey]) {
        xButton.titleLabel.font = [UIFont jhFontWithObject:paraDic[kJHFontKey]];
    }
    if (paraDic[kJHTargetKey] && paraDic[kJHSelectorKey]) {
        [xButton addTarget:paraDic[kJHTargetKey]
                    action:NSSelectorFromString(paraDic[kJHSelectorKey])
          forControlEvents:UIControlEventTouchUpInside];
    }
    if (paraDic[kJHBackgroundImageKey]) {
        [xButton setBackgroundImage:[UIImage imageNamed:paraDic[kJHBackgroundImageKey]] forState:UIControlStateNormal];
    }
    if (paraDic[kJHNormalImageKey]) {
        [xButton setImage:[UIImage imageNamed:paraDic[kJHNormalImageKey]] forState:UIControlStateNormal];
    }
    if (paraDic[kJHHighlightedImageKey]) {
        [xButton setImage:[UIImage imageNamed:paraDic[kJHHighlightedImageKey]] forState:UIControlStateHighlighted];
    }
    if (paraDic[kJHSelectedImageKey]) {
        [xButton setImage:[UIImage imageNamed:paraDic[kJHSelectedImageKey]] forState:UIControlStateSelected];
    }
    if (paraDic[kJHTintColorKey]) {
        xButton.tintColor = [UIColor jhColorWithObject:paraDic[kJHTintColorKey]];
    }
}

@end

#pragma mark -
@implementation UIScrollView (JHCreateCategory)

+ (UIScrollView *)jhUIScrollViewWithDic:(NSDictionary *)paraDic
                              superView:(UIView *)superView
{
    UIScrollView *xScrollView = [[UIScrollView alloc] init];
    xScrollView.pagingEnabled = NO;
    xScrollView.showsHorizontalScrollIndicator = NO;
    xScrollView.showsVerticalScrollIndicator = NO;
  
    if (superView) {
        [superView addSubview:xScrollView];
    }
    
    [self jhUpdateUIScrollView:xScrollView paraDic:paraDic superView:superView];

    return xScrollView;
}

+ (void)jhUpdateUIScrollView:(UIScrollView *)xUIScrollView
                     paraDic:(NSDictionary *)paraDic
                   superView:(UIView *)superView
{
    [self jhUpdateUIView:xUIScrollView paraDic:paraDic superView:superView];
    id size = paraDic[kJHContentSizeKey];
    if ([size isKindOfClass:[NSValue class]]) {
        xUIScrollView.contentSize = [paraDic[kJHContentSizeKey] CGSizeValue];
    }
    else if ([size isKindOfClass:[NSString class]]) {
        NSString *sizeStr = (NSString *)size;
        if ([sizeStr hasPrefix:@"{"]) {
            xUIScrollView.contentSize = CGSizeFromString(sizeStr);
        }else if ([sizeStr hasPrefix:@"["]){
            xUIScrollView.contentSize = [superView jhSizeFromString:sizeStr];
        }
    }
    if (paraDic[kJHDelegateKey]) {
        xUIScrollView.delegate = paraDic[kJHDelegateKey];
    }
}

@end

#pragma mark -
@implementation UITableView (JHCreateCategory)

+ (UITableView *)jhUITableViewWithDic:(NSDictionary *)paraDic
                            superView:(UIView *)superView
{
    UITableView *xTableView = [[UITableView alloc] init];
    if (paraDic[kJHFrameKey]) {
        
        id frame = paraDic[kJHFrameKey];
        CGRect tframe = CGRectZero;
        if ([frame isKindOfClass:[NSString class]])
        {
            NSString *frameStr = (NSString *)frame;
            if ([frameStr hasPrefix:@"{"]) {
                tframe = CGRectFromString(paraDic[kJHFrameKey]);
            }else if ([frameStr hasPrefix:@"["]){
                tframe = [xTableView jhRectFromString:frameStr];
            }
        }
        else if ([frame isKindOfClass:[NSValue class]])
        {
            tframe = [paraDic[kJHFrameKey] CGRectValue];
        }
        
        if (paraDic[kJHTableViewStyleKey]) {
            xTableView = [[UITableView alloc] initWithFrame:tframe
                                                      style:[paraDic[kJHTableViewStyleKey] integerValue]];
        }else{
            xTableView = [[UITableView alloc] initWithFrame:tframe];
        }
    }else{
        
        CGRect bounds = [UIScreen mainScreen].bounds;
        
        CGFloat tX = 0;
        CGFloat tY = 0;
        CGFloat tW = bounds.size.width;
        CGFloat tH = bounds.size.height - tY;
        CGRect  frame = CGRectMake(tX, tY, tW, tH);
        xTableView = [[UITableView alloc] initWithFrame:frame];
        //NSAssert(paraDic[kJHFrameKey] != nil, @"the key 'kJHFrameKey' need a value!!");
    }
    
    xTableView.tableFooterView = [[UIView alloc] init];
    
    if (paraDic[kJHAlphaKey]) {
        xTableView.alpha = [paraDic[kJHAlphaKey] floatValue];
    }
    if (paraDic[kJHBackgroundColorKey]) {
        xTableView.backgroundColor = [UIColor jhColorWithObject:paraDic[kJHBackgroundColorKey]];
    }
    if (paraDic[kJHBorderColorKey]) {
        xTableView.layer.borderColor = [[UIColor jhColorWithObject:paraDic[kJHBorderColorKey]] CGColor];
    }
    if (paraDic[kJHBorderWidthKey]) {
        xTableView.layer.borderWidth = [paraDic[kJHBorderWidthKey] floatValue];
    }
    if (paraDic[kJHCornerRadiusKey]) {
        xTableView.layer.cornerRadius = [paraDic[kJHCornerRadiusKey] floatValue];
    }
    if (paraDic[kJHTagKey]) {
        xTableView.tag = [paraDic[kJHTagKey] integerValue];
    }
    if (paraDic[kJHDelegateKey]) {
        xTableView.delegate = paraDic[kJHDelegateKey];
    }
    if (paraDic[kJHDataSourceKey]) {
        xTableView.dataSource = paraDic[kJHDataSourceKey];
    }
    if (superView) {
        [superView addSubview:xTableView];
    }
    return xTableView;
}

@end

#pragma mark -
@implementation UITextField (JHCreateCategory)

JH_CREATE_CLASS_m(UITextField)

+ (void)jhUpdateUITextField:(UITextField *)xUITextField
                    paraDic:(NSDictionary *)paraDic
                  superView:(UIView *)superView
{
    [self jhUpdateUIView:xUITextField paraDic:paraDic superView:superView];
    
    if (paraDic[kJHPlaceholderKey]) {
        xUITextField.placeholder = paraDic[kJHPlaceholderKey];
    }
    if (paraDic[kJHPlaceholderColorKey]) {
        [xUITextField setValue:[UIColor jhColorWithObject:paraDic[kJHPlaceholderColorKey]] forKeyPath:@"_placeholderLabel.textColor"];
    }
    if (paraDic[kJHPlaceholderFontKey]) {
        [xUITextField setValue:[UIFont jhFontWithObject:paraDic[kJHPlaceholderFontKey]] forKeyPath:@"_placeholderLabel.font"];
    }
    if (paraDic[kJHClearButtonModeKey]) {
        xUITextField.clearButtonMode = [paraDic[kJHClearButtonModeKey] integerValue];
    }
    if (paraDic[kJHLeftViewKey]) {
        xUITextField.leftView = paraDic[kJHLeftViewKey];
    }
    if (paraDic[kJHLeftViewModeKey]) {
        xUITextField.leftViewMode = [paraDic[kJHLeftViewModeKey] integerValue];
    }
    if (paraDic[kJHBorderStyleKey]) {
        xUITextField.borderStyle = [paraDic[kJHBorderStyleKey] integerValue];
    }
    if (paraDic[kJHTextKey]){
        xUITextField.text = paraDic[kJHTextKey];
    }
    if (paraDic[kJHTextColorKey]){
        xUITextField.textColor = [UIColor jhColorWithObject:paraDic[kJHTextColorKey]];
    }
    if (paraDic[kJHFontKey]){
        xUITextField.font = [UIFont jhFontWithObject:paraDic[kJHFontKey]];
    }
    if (paraDic[kJHTextAlignmentKey]){
        xUITextField.textAlignment = [paraDic[kJHTextAlignmentKey] integerValue];
    }

}

@end

#pragma mark -
@implementation UITextView (JHCreateCategory)

JH_CREATE_CLASS_m(UITextView)

+ (void)jhUpdateUITextView:(UITextView *)xUITextView
                   paraDic:(NSDictionary *)paraDic
                 superView:(UIView *)superView
{
    [self jhUpdateUIView:xUITextView paraDic:paraDic superView:superView];
    
    if (paraDic[kJHTextKey]){
        xUITextView.text = paraDic[kJHTextKey];
    }
    if (paraDic[kJHTextColorKey]){
        xUITextView.textColor = [UIColor jhColorWithObject:paraDic[kJHTextColorKey]];
    }
    if (paraDic[kJHFontKey]){
        xUITextView.font = [UIFont jhFontWithObject:paraDic[kJHFontKey]];
    }
    if (paraDic[kJHTextAlignmentKey]){
        xUITextView.textAlignment = [paraDic[kJHTextAlignmentKey] integerValue];
    }
    if (paraDic[kJHDelegateKey]){
        xUITextView.delegate = paraDic[kJHDelegateKey];
    }
}

@end

#pragma mark -
@implementation UIImageView (JHCreateCategory)

JH_CREATE_CLASS_m(UIImageView)

+ (void)jhUpdateUIImageView:(UIImageView *)xUIImageView
                    paraDic:(NSDictionary *)paraDic
                  superView:(UIView *)superView
{
    [self jhUpdateUIView:xUIImageView paraDic:paraDic superView:superView];
    if (paraDic[kJHImageKey]) {
        xUIImageView.image = [UIImage imageNamed:paraDic[kJHImageKey]];
    }
}

@end

#pragma mark -
@implementation UISwitch (JHCreateCategory)

JH_CREATE_CLASS_m(UISwitch)

+ (void)jhUpdateUISwitch:(UISwitch *)xUISwitch
                 paraDic:(NSDictionary *)paraDic
               superView:(UIView *)superView
{
    //switch 的宽高是固定的 w-51  h-31
    id frame = paraDic[kJHFrameKey];
    if ([frame isKindOfClass:[NSValue class]])
    {
        if (paraDic[kJHFrameKey]) {
            xUISwitch.frame = [paraDic[kJHFrameKey] CGRectValue];
        }
    }
    else if ([frame isKindOfClass:[NSString class]])
    {
        NSString *frameStr = (NSString *)frame;
        if ([frameStr hasPrefix:@"{"]) {
            xUISwitch.frame = CGRectFromString(paraDic[kJHFrameKey]);
        }else if ([frameStr hasPrefix:@"["]){
            xUISwitch.frame = [xUISwitch jhRectFromString:frameStr];
        }
    }
    if (paraDic[kJHTintColorKey]){
        xUISwitch.tintColor = [UIColor jhColorWithObject:paraDic[kJHTintColorKey]];
    }
    if (paraDic[kJHOnTintColorKey]){
        xUISwitch.onTintColor = [UIColor jhColorWithObject:paraDic[kJHOnTintColorKey]];
    }
    if (paraDic[kJHThumbTintColorKey]) {
        xUISwitch.thumbTintColor = [UIColor jhColorWithObject:paraDic[kJHThumbTintColorKey]];
    }
    if (paraDic[kJHOnImageKey]){
        xUISwitch.onImage = [UIImage imageNamed:paraDic[kJHOnImageKey]];
    }
    if (paraDic[kJHOffImageKey]){
        xUISwitch.offImage = [UIImage imageNamed:paraDic[kJHOffImageKey]];
    }
    if (paraDic[kJHTagKey]) {
        xUISwitch.tag = [paraDic[kJHTagKey] integerValue];
    }
    if (paraDic[kJHTargetKey] && paraDic[kJHSelectorKey]) {
        [xUISwitch addTarget:paraDic[kJHTargetKey]
                      action:NSSelectorFromString(paraDic[kJHSelectorKey])
            forControlEvents:UIControlEventValueChanged];
    }
}

@end

#pragma mark -
@implementation UISlider (JHCreateCategory)

JH_CREATE_CLASS_m(UISlider)

+ (void)jhUpdateUISlider:(UISlider *)xUISlider
                 paraDic:(NSDictionary *)paraDic
               superView:(UIView *)superView
{
    id frame = paraDic[kJHFrameKey];
    if ([frame isKindOfClass:[NSValue class]])
    {
        if (paraDic[kJHFrameKey]) {
            xUISlider.frame = [paraDic[kJHFrameKey] CGRectValue];
        }
    }
    else if ([frame isKindOfClass:[NSString class]])
    {
        NSString *frameStr = (NSString *)frame;
        if ([frameStr hasPrefix:@"{"]) {
            xUISlider.frame = CGRectFromString(paraDic[kJHFrameKey]);
        }else if ([frameStr hasPrefix:@"["]){
            xUISlider.frame = [xUISlider jhRectFromString:frameStr];
        }
    }
    if (paraDic[kJHValueKey]) {
        xUISlider.value = [paraDic[kJHValueKey] floatValue];
    }
    if (paraDic[kJHMinimumValueKey]) {
        xUISlider.minimumValue = [paraDic[kJHMinimumValueKey] floatValue];
    }
    if (paraDic[kJHMaximumValueKey]) {
        xUISlider.maximumValue = [paraDic[kJHMaximumValueKey] floatValue];
    }
    if (paraDic[kJHTargetKey] && paraDic[kJHSelectorKey]) {
        [xUISlider addTarget:paraDic[kJHTargetKey]
                      action:NSSelectorFromString(paraDic[kJHSelectorKey])
            forControlEvents:UIControlEventValueChanged];
    }
}

@end

#pragma mark -
@implementation UIStepper (JHCreateCategory)

JH_CREATE_CLASS_m(UIStepper)

+ (void)jhUpdateUIStepper:(UIStepper *)xUIStepper
                  paraDic:(NSDictionary *)paraDic
                superView:(UIView *)superView
{
    id frame = paraDic[kJHFrameKey];
    if ([frame isKindOfClass:[NSValue class]])
    {
        if (paraDic[kJHFrameKey]) {
            xUIStepper.frame = [paraDic[kJHFrameKey] CGRectValue];
        }
    }
    else if ([frame isKindOfClass:[NSString class]])
    {
        NSString *frameStr = (NSString *)frame;
        if ([frameStr hasPrefix:@"{"]) {
            xUIStepper.frame = CGRectFromString(paraDic[kJHFrameKey]);
        }else if ([frameStr hasPrefix:@"["]){
            xUIStepper.frame = [xUIStepper jhRectFromString:frameStr];
        }
    }
    if (paraDic[kJHValueKey]) {
        xUIStepper.value = [paraDic[kJHValueKey] longValue];
    }
    if (paraDic[kJHMinimumValueKey]) {
        xUIStepper.minimumValue = [paraDic[kJHMinimumValueKey] longValue];
    }
    if (paraDic[kJHMaximumValueKey]) {
        xUIStepper.maximumValue = [paraDic[kJHMaximumValueKey] longValue];
    }
    if (paraDic[kJHStepValueKey]) {
        xUIStepper.stepValue = [paraDic[kJHStepValueKey] longValue];
    }
    if (paraDic[kJHTintColorKey]) {
        xUIStepper.tintColor = [UIColor jhColorWithObject:paraDic[kJHTintColorKey]];
    }
    if (paraDic[kJHTargetKey] && paraDic[kJHSelectorKey]) {
        [xUIStepper addTarget:paraDic[kJHTargetKey]
                       action:NSSelectorFromString(paraDic[kJHSelectorKey])
             forControlEvents:UIControlEventValueChanged];
    }
}

@end

#pragma mark -
@implementation UISegmentedControl (JHCreateCategory)

+ (UISegmentedControl *)jhUISegmentedControlWithDic:(NSDictionary *)paraDic
                                          superView:(UIView *)superView
{
    UISegmentedControl *xSegment = nil;
    if (paraDic[kJHItemsKey]) {
        xSegment = [[UISegmentedControl alloc] initWithItems:paraDic[kJHItemsKey]];
    }else{
        return nil;
    }
    
    [self jhUpdateUISegmentedControl:xSegment paraDic:paraDic superView:superView];
    
    if (superView) {
        [superView addSubview:xSegment];
    }
    return xSegment;
}


+ (void)jhUpdateUISegmentedControl:(UISegmentedControl *)xUISegmentedControl
                           paraDic:(NSDictionary *)paraDic
                         superView:(UIView *)superView
{
    id frame = paraDic[kJHFrameKey];
    if ([frame isKindOfClass:[NSValue class]])
    {
        if (paraDic[kJHFrameKey]) {
            xUISegmentedControl.frame = [paraDic[kJHFrameKey] CGRectValue];
        }
    }
    else if ([frame isKindOfClass:[NSString class]])
    {
        NSString *frameStr = (NSString *)frame;
        if ([frameStr hasPrefix:@"{"]) {
            xUISegmentedControl.frame = CGRectFromString(paraDic[kJHFrameKey]);
        }else if ([frameStr hasPrefix:@"["]){
            xUISegmentedControl.frame = [xUISegmentedControl jhRectFromString:frameStr];
        }
    }
    if (paraDic[kJHTintColorKey]) {
        xUISegmentedControl.tintColor = [UIColor jhColorWithObject:paraDic[kJHTintColorKey]];
    }
    if (paraDic[kJHSelectedSegmentIndexKey]) {
        xUISegmentedControl.selectedSegmentIndex = [paraDic[kJHSelectedSegmentIndexKey] integerValue];
    }
    if (paraDic[kJHTargetKey] && paraDic[kJHSelectorKey]) {
        [xUISegmentedControl addTarget:paraDic[kJHTargetKey]
                                action:NSSelectorFromString(paraDic[kJHSelectorKey])
                      forControlEvents:UIControlEventValueChanged];
    }
}

@end
#endif
#endif
