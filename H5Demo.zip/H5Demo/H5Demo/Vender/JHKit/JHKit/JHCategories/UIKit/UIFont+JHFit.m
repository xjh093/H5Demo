//
//  UIFont+JHFit.m
//  JHKit
//
//  Created by HaoCold on 2018/5/17.
//  Copyright © 2018年 HaoCold. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2018 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import "UIFont+JHFit.h"
#import <objc/runtime.h>

#define kCurrentScreenWidth [[UIScreen mainScreen] bounds].size.width

#define kIS_IPHONE_4  ([[UIScreen mainScreen] bounds].size.height == 480.0f)
#define kIS_IPHONE_5  ([[UIScreen mainScreen] bounds].size.height == 568.0f)
#define kIS_IPHONE_6  ([[UIScreen mainScreen] bounds].size.height == 667.0f)
#define kIS_IPHONE_6P ([[UIScreen mainScreen] bounds].size.height == 736.0f)
#define kIS_IPHONE_X  ([[UIScreen mainScreen] bounds].size.height == 812.0f)

@implementation UIFont (JHFit)

+ (UIFont *)jh_systemFontOfSize:(CGFloat)size
{
    UIFont *font;
    if (kIS_IPHONE_6P || kIS_IPHONE_X) {
        font = [self jh_systemFontOfSize:size*1.5];
    }else{
        font =[self jh_systemFontOfSize:size];
    }
    return font;
}

+ (UIFont *)jh_boldSystemFontOfSize:(CGFloat)size
{
    UIFont *font;
    if (kIS_IPHONE_6P || kIS_IPHONE_X) {
        font = [self jh_boldSystemFontOfSize:size*1.5];
    }else{
        font =[self jh_boldSystemFontOfSize:size];
    }
    return font;
}

@end
