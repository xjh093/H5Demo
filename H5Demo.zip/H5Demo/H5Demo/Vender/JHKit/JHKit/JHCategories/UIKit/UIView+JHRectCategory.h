//
//  UIView+JHRectCategory.h
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import <UIKit/UIKit.h>

@interface UIView (JHRectCategory)

/// view.frame.origin.x
@property (assign, nonatomic) CGFloat jh_x;
/// view.frame.origin.y
@property (assign, nonatomic) CGFloat jh_y;
/// view.frame.size.width
@property (assign, nonatomic) CGFloat jh_w;
/// view.frame.size.height
@property (assign, nonatomic) CGFloat jh_h;
/// view.frame.origin
@property (assign, nonatomic) CGPoint jh_origin;
/// view.frame.size
@property (assign, nonatomic) CGSize  jh_size;
/// view.center.x
@property (assign, nonatomic) CGFloat jh_center_x;
/// view.center.y
@property (assign, nonatomic) CGFloat jh_center_y;
/// view MaxX
@property (assign, nonatomic) CGFloat jh_max_x;
/// view MaxY
@property (assign, nonatomic) CGFloat jh_max_y;             
/// view MidX
@property (assign, nonatomic) CGFloat jh_mid_x;
/// view MidY
@property (assign, nonatomic) CGFloat jh_mid_y;

@end
