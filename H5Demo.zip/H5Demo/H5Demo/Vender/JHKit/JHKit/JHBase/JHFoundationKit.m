//
//  JHFoundationKit.h
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import "JHFoundationKit.h"

//=============================================================================//
//  CrashManager
//=============================================================================//
@implementation JHCrashManager

+ (void)jh_startCaughtException
{
    NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
}

void uncaughtExceptionHandler(NSException *exception)
{
#if DEBUG
    NSLog(@"Crash!!!-_-!  here is the info:\n name:%@\n reason:%@\n callStack:%@",exception.name,exception.reason,exception.callStackSymbols);
#elif 0
    NSDictionary *dic = @{@"name":exception.name,
                          @"resaon":exception.reason,
                          @"callStackSysbols":exception.callStackSymbols};
    NSData *data = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
    //[data writeToFile:@"/Users/haocold/Desktop/13726796592.txt" atomically:NO]; //用字典写入文件，会写成plist
    
    NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    [str writeToFile:@"/Users/haocold/Desktop/CrsahLog.txt" atomically:NO encoding:NSUTF8StringEncoding error:nil];
#endif
}

@end

//=============================================================================//
//  Model
//=============================================================================//
@implementation NSObject (JHModel)

+ (instancetype)modelWithDictionary:(NSDictionary *)dic
{
    id class = [self new];
    if ([dic isKindOfClass:[NSDictionary class]]) {
        [class setValuesForKeysWithDictionary:dic];
    }
    return class;
}

+ (NSArray *)modelArrayWithDictionaryArray:(NSArray *)arr
{
    NSMutableArray *xArr = @[].mutableCopy;
    for (NSDictionary *dic in arr) {
        if ([dic isKindOfClass:[NSDictionary class]]) {
            [xArr addObject:[self modelWithDictionary:dic]];
        }
    }
    return xArr;
}

@end


@implementation JHHTTPProxyCheck

+ (BOOL)jh_httpProxyCheck{
    
    NSURL *URL = [NSURL URLWithString:@"https://www.baidu.com"];
    CFURLRef URLRef = (__bridge CFURLRef)URL;
    CFDictionaryRef proxySettingsRef = CFNetworkCopySystemProxySettings();
    CFArrayRef arrayRef = CFNetworkCopyProxiesForURL(URLRef, proxySettingsRef);
    NSDictionary *settingDic = ((__bridge NSArray *)arrayRef)[0];
    
    NSLog(@"\n----------\n"
          "jh_httpProxyCheck:\n"
          "ProxyHostName:%@\n"
          "ProxyPortNumber:%@\n"
          "ProxyType:%@\n"
          "----------\n",
          settingDic[(NSString *)kCFProxyHostNameKey],
          settingDic[(NSString *)kCFProxyPortNumberKey],
          settingDic[(NSString *)kCFProxyTypeKey]
          );
    
    /*
     Possible values for kCFProxyTypeKey:
     kCFProxyTypeNone - no proxy should be used; contact the origin server directly
     kCFProxyTypeHTTP - the proxy is an HTTP proxy
     kCFProxyTypeHTTPS - the proxy is a tunneling proxy as used for HTTPS
     kCFProxyTypeSOCKS - the proxy is a SOCKS proxy
     kCFProxyTypeFTP - the proxy is an FTP proxy
     kCFProxyTypeAutoConfigurationURL - the proxy is specified by a proxy autoconfiguration (PAC) file
     */
    
    NSString *value = settingDic[(NSString *)kCFProxyTypeKey];
    if ([value isEqualToString:(NSString *)kCFProxyTypeNone]) {
        NSLog(@"手机网络没有设置代理");
        return NO;
    }else{
        NSLog(@"手机网络设置了代理！");
        return YES;
    }
}

@end

