//
//  JHUIKit.m
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#import "JHUIKit.h"

@implementation JHCreateUI : NSObject

UIView *xxAddView(CGRect frame,UIColor *bgColor,UIView *superView)
{
    UIView *view = [[UIView alloc] init];
    view.frame = frame;
    view.backgroundColor = bgColor;
    
    if (superView) {
        [superView addSubview:view];
    }
    return view;
}

UIView *xxAddView1(CGRect frame,NSString *imageName,UIView *superView)
{
    UIView *view = [[UIView alloc] init];
    view.frame = frame;
    
    UIImage *image = [UIImage imageNamed:imageName];
    if (image) {
        view.layer.contents = (id)[image CGImage];
    }
    
    if (superView) {
        [superView addSubview:view];
    }
    return view;
}

UILabel *xxAddLabel(CGRect frame,NSString *text,UIColor *color,UIFont *font,NSTextAlignment align,UIView *superView)
{
    UILabel *lable = [[UILabel alloc] init];
    lable.frame = frame;
    lable.text = text;
    lable.font = font;
    lable.textAlignment = align;
    lable.textColor = color;
    
    if (superView) {
        [superView addSubview:lable];
    }
    return lable;
}

UIButton *xxAddButton(CGRect frame,NSString *title,UIColor *color,UIFont *font,UIImage *image,UIImage *bgImage,UIView *superView)
{
    UIButton *button = [[UIButton alloc] init];
    button.frame = frame;
    [button setImage:image forState:0];
    [button setTitle:title forState:0];
    [button setTitleColor:color forState:0];
    [button setBackgroundImage:bgImage forState:0];
    button.titleLabel.font = font;
    
    if (superView) {
        [superView addSubview:button];
    }
    return button;
}

CALayer *xxAddLayer(CGRect frame,UIColor *color,NSString *imageName,UIColor *bdcolor,CGFloat bdWidth,UIView *superView)
{
    CALayer *layer = [[CALayer alloc] init];
    layer.frame = frame;
    layer.backgroundColor = color.CGColor;
    layer.borderColor = bdcolor.CGColor;
    layer.borderWidth = bdWidth;
    
    if (imageName.length > 0) {
        layer.contents = (id)[UIImage imageNamed:imageName].CGImage;
    }
    
    if (superView) {
        [superView.layer addSublayer:layer];
    }
    return layer;
}

UIImageView *xxAddImageView(CGRect frame,NSString *image,UIView *superView)
{
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.frame = frame;
    imageView.image = [UIImage imageNamed:image];
    if (superView) {
        [superView addSubview:imageView];
    }
    return imageView;
}

UIImageView *xxAddImageView1(CGRect frame,UIImage *image,CGFloat radius,UIColor *bgColor,UIView *superView)
{
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.frame = frame;
    imageView.image = image;
    imageView.backgroundColor = bgColor;
    
    if (radius > 0) {
        imageView.layer.masksToBounds = YES;
        imageView.layer.cornerRadius = radius;
    }
    
    if (superView) {
        [superView addSubview:imageView];
    }
    return imageView;
}

@end

