//
//  JHKit.h
//  JHKit
//
//  Created by Lightech on 14-10-16.
//  Copyright (c) 2014年 Lightech. All rights reserved.
//
//  MIT License
//
//  Copyright (c) 2017 xjh093
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

#ifndef JHKit_h
#define JHKit_h

#import "JHUIKit.h"
#import "JHFoundationKit.h"
#import "JHCategories.h"

#endif

/**< 

.jh_addToView(<#spview#>)
.jh_frame(@"[x:,y:,w:,h:]")
.jh_tag(@(100));

JH_LAZY_STRONG_UI(UIView, <#view#>, ({
    UIView
    .jhView()
    .jh_bgColor(@"0xeeeeee");
}))


JH_LAZY_STRONG_UI(UILabel, <#label#>, ({
    UILabel
    .jhLabel()
    .jh_text(@"")
    .jh_color(@"0x000000")
    .jh_font(@(16))
    .jh_align(@(1));
}))

JH_LAZY_STRONG_UI(UIButton, <#button#>, ({
    UIButton
    .jhButton(@(0))
    .jh_title(@"")
    .jh_color(@"0x000000")
    .jh_image(@"name")
    .jh_bgColor(@"0xeeeeee")
    .jh_target_selector_event(self,@"jhButtonEvent:",@(1<<6));
}))

JH_LAZY_STRONG_UI(UITextField, <#textField#>, ({
    UITextField
    .jhTextField()
    .jh_pHolder(@"在此输入内容")
    .jh_lvMode(@(3))
    .jh_lfView(({
        UIView
        .jhView()
        .jh_frame(@"{{0,0},{5,5}}");
    }));
}))
 */
