//
//  JHUserInfoVC.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/18.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHUserInfoVC.h"

@interface JHUserInfoVC ()

@end

@implementation JHUserInfoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self xjh_setupViews];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:({
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.titleLabel.font = [UIFont systemFontOfSize:16];
        [button setTitle:@"关闭页面" forState:0];
        [button setTitleColor:[UIColor blackColor] forState:0];
        [button addTarget:self action:@selector(xjh_click_button) forControlEvents:1<<6];
        [button sizeToFit];
        button;
    })];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -------------------------------------视图-------------------------------------------

- (void)xjh_setupViews
{
    // load html
    NSString *path = [[NSBundle mainBundle] bundlePath];
    NSURL *baseURL = [NSURL fileURLWithPath:path];
    NSString * htmlPath = [[NSBundle mainBundle] pathForResource:@"userinfo"
                                                          ofType:@"html"];
    NSString * htmlContent = [NSString stringWithContentsOfFile:htmlPath
                                                       encoding:NSUTF8StringEncoding
                                                          error:nil];
    
    [self.webView loadHTMLString:htmlContent baseURL:baseURL];
    self.frameType = JHWebViewFrameType_Navigation;
    self.refreshType = JHRefreshType_Both;
    [self updateViewFrame];
}

#pragma mark -------------------------------------事件-------------------------------------------

- (void)xjh_click_button
{
    // qb://clientUserAction/(前端页面路由)?action=(refresh,loadMore,click)&target=(当action=click时需要添加target参数back,title,subtitle)
    NSString *url = [NSString stringWithFormat:@"qb://clientUserAction/%@?action=click&target=back",self.identifier];
    [self evaluateJavaScript:url];
}

#pragma mark -------------------------------------懒加载-----------------------------------------


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
