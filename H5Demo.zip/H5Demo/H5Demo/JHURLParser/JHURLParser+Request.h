//
//  JHURLParser+Request.h
//  H5Demo
//
//  Created by xuejinghao on 2018/7/17.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHURLParser.h"

@interface JHURLParser (Request)

/**
 request for URL.
 
 @param URL URL.
 @param type get or post.
 @param dic parameters.
 @param vc vc.
 */
+ (void)requestWithURL:(NSURL *)URL
                  type:(NSString *)type
                params:(NSDictionary *)dic
                 forVC:(JHBaseH5VC *)vc;

@end
