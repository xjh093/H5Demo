//
//  JHURLParser+Call.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/18.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHURLParser+Call.h"
#import "JHBaseH5VC.h"

@implementation JHURLParser (Call)

// qb://dial?tel=13165315641
+ (void)callWithURL:(NSURL *)URL
             params:(NSDictionary *)dic
              forVC:(JHBaseH5VC *)vc
{
#if 1
    NSString *tel = [NSString stringWithFormat:@"tel://%@",dic[@"tel"]];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:tel]];
#else
    NSString *tel = [NSString stringWithFormat:@"telprompt://%@",dic[@"tel"]];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:tel]];
#endif
}

@end
