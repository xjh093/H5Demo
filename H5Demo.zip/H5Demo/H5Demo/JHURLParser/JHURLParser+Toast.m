//
//  JHURLParser+Toast.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/18.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHURLParser+Toast.h"
#import "JHAlertView.h"

@implementation JHURLParser (Toast)

// qb://toast?message=(吐司内容)&position=(top,center,bottom默认bottom)
+ (void)toastWithURL:(NSURL *)URL
              params:(NSDictionary *)dic
               forVC:(JHBaseH5VC *)vc
{
    //
    NSString *message  = dic[@"message"];
    // NSString *position = dic[@"position"]; // 不使用位置
    
#if kJHDebug
    XX_HUD_SHOW_CUSTOM_ONLY(message, 2, nil);
#else
    // 使用 MB 展示一下
    
#endif
}

@end
