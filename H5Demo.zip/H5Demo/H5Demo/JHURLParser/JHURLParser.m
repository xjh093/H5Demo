//
//  JHURLParser.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/17.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHURLParser.h"
#import "JHBaseH5VC.h"
#import "JHURLParser+Request.h"
#import "JHURLParser+Goto.h"
#import "JHURLParser+Alert.h"
#import "JHURLParser+Call.h"
#import "JHURLParser+Video.h"
#import "JHURLParser+Refresh.h"
#import "JHURLParser+Close.h"
#import "JHURLParser+Token.h"
#import "JHURLParser+Toast.h"

@implementation JHURLParser

+ (void)parseURL:(NSURL *)URL forVC:(JHBaseH5VC *)vc
{
    NSString *scheme = URL.scheme;
    NSString *host   = URL.host;
    NSNumber *port   = URL.port;
    NSString *path   = URL.path;
    NSString *query  = URL.query;
    
    NSLog(@"URL:\nscheme:%@\nhost:%@\nport:%@\npath:%@\nquery:%@",scheme,host,port,path,[query stringByRemovingPercentEncoding]);
    
    //[@"" stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLQueryAllowedCharacterSet];
    /**<  qb://get/userinfo?userId=1
     scheme:qb
     host:get
     port:(null)
     path:/userinfo
     query:userId=1
     */
    
    // 把参数转换成字典
    NSDictionary *dic;
    
    if (query) {
        dic = [self parametersFromQuery:query];
    }
    
    if ([host isEqualToString:@"get"] ||
        [host isEqualToString:@"post"]) {
        [JHURLParser requestWithURL:URL type:host params:dic forVC:vc];
    }else if ([host isEqualToString:@"goto"]) {
        [JHURLParser gotoWithURL:URL params:dic forVC:vc];
    }else if ([host isEqualToString:@"dialog"]) {
        [JHURLParser alertWithURL:URL params:dic forVC:vc];
    }else if ([host isEqualToString:@"dial"]) {
        [JHURLParser callWithURL:URL params:dic forVC:vc];
    }else if ([host isEqualToString:@"video"]) {
        [JHURLParser videoWithURL:URL params:dic forVC:vc];
    }else if ([host isEqualToString:@"refreshComplete"]) {
        [JHURLParser refreshWithURL:URL params:dic forVC:vc];
    }else if ([host isEqualToString:@"refresh"]) {
        [JHURLParser refreshWithURL:URL params:dic forVC:vc];
    }else if ([host isEqualToString:@"finish"]) {
        [JHURLParser closeWithURL:URL params:dic forVC:vc];
    }else if ([host isEqualToString:@"token"]) {
        [JHURLParser tokenWithURL:URL params:dic forVC:vc];
    }else if ([host isEqualToString:@"toast"]) {
        [JHURLParser toastWithURL:URL params:dic forVC:vc];
    }
}

+ (void)callback:(NSURL *)URL response:(id)responseObject forVC:(JHBaseH5VC *)vc{
    NSString *api = [URL.absoluteString stringByRemovingPercentEncoding];
    NSString *result = [NSString jh_JSONStringFromDictionary:responseObject];
    NSString *method = [NSString stringWithFormat:@"apiResult(\"%@\",%@)",api,result];
    [vc.webView evaluateJavaScript:method completionHandler:^(id _Nullable result, NSError * _Nullable error) {
        NSLog(@"result:%@,error:%@",result,error);
    }];
}

+ (NSDictionary *)parametersFromQuery:(NSString *)query
{
    query = [query stringByRemovingPercentEncoding];
    NSArray *array = [query componentsSeparatedByString:@"&"];
    
    NSMutableDictionary *mdic = @{}.mutableCopy;
    for (NSString *element in array) {
        NSArray *subArr = [element componentsSeparatedByString:@"="];
        if (subArr.count == 2) {
            [mdic setValue:subArr[1] forKey:subArr[0]];
        }
    }
    
    return mdic;
}

@end
