//
//  JHURLParser.h
//  H5Demo
//
//  Created by xuejinghao on 2018/7/17.
//  Copyright © 2018年 HN. All rights reserved.
//

#import <Foundation/Foundation.h>

@class JHBaseH5VC;

@interface JHURLParser : NSObject

/**
 解析URL.
 
 @param URL URL.
 @param vc 当前控制器.
 */
+ (void)parseURL:(NSURL *)URL forVC:(JHBaseH5VC *)vc;

/**
 回调数据给H5.
 
 @param URL URL.
 @param responseObject 数据.
 @param vc 当前控制器.
 */
+ (void)callback:(NSURL *)URL response:(id)responseObject forVC:(JHBaseH5VC *)vc;

@end
