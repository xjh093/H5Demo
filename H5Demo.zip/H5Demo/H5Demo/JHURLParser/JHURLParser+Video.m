//
//  JHURLParser+Video.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/18.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHURLParser+Video.h"

@implementation JHURLParser (Video)

// qb://video?videoUrl=http://baidu.com/video.map4
+ (void)videoWithURL:(NSURL *)URL
              params:(NSDictionary *)dic
               forVC:(JHBaseH5VC *)vc
{
    NSString *videoUrl = dic[@"videoUrl"];
    NSString *message = [NSString stringWithFormat:@"观看视频：%@",videoUrl];
    
    UIAlertController
    .jhAlertCtrl(@"提示", message, @(1))
    .jh_addNormalAction(@"确定",^{
        //code
    })
    .jh_addCancelAction(@"取消",^{
        //code
    })
    .jh_show(vc);
}

@end
