//
//  JHURLParser+Refresh.h
//  H5Demo
//
//  Created by xuejinghao on 2018/7/18.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHURLParser.h"

@interface JHURLParser (Refresh)

/**
 刷新.
 
 @param URL URL.
 @param dic parameters.
 @param vc vc.
 */
+ (void)refreshWithURL:(NSURL *)URL
                params:(NSDictionary *)dic
                 forVC:(JHBaseH5VC *)vc;

@end
