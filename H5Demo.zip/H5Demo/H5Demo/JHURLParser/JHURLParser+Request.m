//
//  JHURLParser+Request.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/17.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHURLParser+Request.h"
#import "JHBaseH5VC.h"
#import "JHNetworkManager.h"

@implementation JHURLParser (Request)

+ (void)requestWithURL:(NSURL *)URL
                  type:(NSString *)type
                params:(NSDictionary *)dic
                 forVC:(JHBaseH5VC *)vc
{
    if ([type isEqualToString:@"get"]) {
        [self GET:URL params:dic forVC:vc];
    }else if ([type isEqualToString:@"post"]){
        [self POST:URL params:dic forVC:vc];
    }
}

// 例如：qb://get/userinfo?userId=1
+ (void)GET:(NSURL *)URL params:(NSDictionary *)dic forVC:(JHBaseH5VC *)vc
{
#if kJHDebug
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self callback:URL response:dic forVC:vc];
    });
#else
    NSString *path = URL.path;
    NSString *url = [NSString stringWithFormat:@"%@%@",kBaseURL,path];
    
    [JHNetworkManager GET:url parameters:dic success:^(id responseObject) {
        NSLog(@"GET url:%@\n responseObject:%@",url,responseObject);
        [self callback:URL response:responseObject forVC:vc];
    } failure:^(NSError *error) {
        NSLog(@"error:%@",error);
    }];
#endif
}

// 例如：qb://post/userinfo?userId=1
+ (void)POST:(NSURL *)URL params:(NSDictionary *)dic forVC:(JHBaseH5VC *)vc
{
#if kJHDebug
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self callback:URL response:dic forVC:vc];
    });
#else
    NSString *path = URL.path;
    NSString *url = [NSString stringWithFormat:@"%@%@",kBaseURL,path];
    
    [JHNetworkManager POST:url parameters:dic success:^(id responseObject) {
        NSLog(@"POST url:%@\n responseObject:%@",url,responseObject);
        [self callback:URL response:responseObject forVC:vc];
    } failure:^(NSError *error) {
        NSLog(@"error:%@",error);
    }];
#endif
}

@end
