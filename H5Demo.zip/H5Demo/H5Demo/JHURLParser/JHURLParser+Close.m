//
//  JHURLParser+Close.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/18.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHURLParser+Close.h"
#import "JHBaseH5VC.h"

@implementation JHURLParser (Close)

// qb://finish/(前端页面路由)
+ (void)closeWithURL:(NSURL *)URL
              params:(NSDictionary *)dic
               forVC:(JHBaseH5VC *)vc
{
    NSString *identifier = URL.path;
    NSMutableArray *vcs = vc.navigationController.viewControllers.mutableCopy;
    JHBaseH5VC *closeVC;
    for (int i = 1; i < vcs.count; i++) {
        JHBaseH5VC *h5vc = vcs[i];
        if ([h5vc.identifier isEqualToString:identifier]) {
            closeVC = h5vc;
            break;
        }
    }
    
    if (closeVC) {
        [vcs removeObject:closeVC];
        vc.navigationController.viewControllers = vcs;
    }
}

@end
