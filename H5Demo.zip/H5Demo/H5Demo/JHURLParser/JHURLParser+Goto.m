//
//  JHURLParser+Goto.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/17.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHURLParser+Goto.h"
#import "JHBaseH5VC.h"

@implementation JHURLParser (Goto)

/**<
 qb://goto/(前端页面路由)?title=xxx&layoutType=(0全屏1有导航栏2tabbar3包含1、2默认是1)refreshMode=(none,both,top,bottom不传则默认为none)
 例如：qb://goto/wallet  表明前端需要跳转页面并路由到wallet界面
 */
+ (void)gotoWithURL:(NSURL *)URL
             params:(NSDictionary *)dic
              forVC:(JHBaseH5VC *)vc
{
    NSString *navTitle   = dic[@"title"];
    NSString *layoutType = dic[@"layoutType"];
    NSString *refreshMode = dic[@"refreshMode"];
    
    NSUInteger frameType = 1;
    if (layoutType) {
        frameType = [layoutType integerValue];
    }
    
    NSDictionary *refreshTypeDic = @{@"none":@0,
                                     @"both":@1,
                                     @"top":@2,
                                     @"bottom":@3};
    
    NSMutableDictionary *mdic = @{}.mutableCopy;
    [mdic setValue:navTitle forKey:@"navTitle"];
    [mdic setValue:@(frameType) forKey:@"frameType"];
    [mdic setValue:refreshTypeDic[refreshMode] forKey:@"refreshType"];
    [mdic setValue:@YES forKey:@"autoLoadURL"];
    [mdic setValue:URL.path forKey:@"url"];
    [mdic setValue:URL.path forKey:@"identifier"];
    
    if (URL.path.length > 1) {
        NSString *vcString = [URL.path substringFromIndex:1];
        Class cls = NSClassFromString(vcString);
        if (cls) {
            [mdic setValue:@NO forKey:@"autoLoadURL"];
            [vc pushSpecifiedVC:vcString parameter:mdic];
        }else{
            [vc pushSpecifiedVC:@"JHBaseH5VC" parameter:mdic];
        }
    }else{
        [vc pushSpecifiedVC:@"JHBaseH5VC" parameter:mdic];
    }
}

@end
