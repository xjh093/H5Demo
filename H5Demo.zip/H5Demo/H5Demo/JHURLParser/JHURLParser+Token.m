//
//  JHURLParser+Token.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/18.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHURLParser+Token.h"

@implementation JHURLParser (Token)

// qb://token?key=(接口请求token的key)&value=(token的值)&target=(header,param)
+ (void)tokenWithURL:(NSURL *)URL
              params:(NSDictionary *)dic
               forVC:(JHBaseH5VC *)vc
{
    NSString *key    = dic[@"key"];
    NSString *value  = dic[@"value"];
    NSString *target = dic[@"target"];
    
    [NSUserDefaults jh_setObject:key forKey:@"__key__"];
    [NSUserDefaults jh_setObject:value forKey:@"__value__"];
    [NSUserDefaults jh_setObject:target forKey:@"__target__"];
    
}

@end
