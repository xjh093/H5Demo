//
//  JHURLParser+Refresh.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/18.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHURLParser+Refresh.h"
#import "JHBaseH5VC.h"

@implementation JHURLParser (Refresh)

+ (void)refreshWithURL:(NSURL *)URL
                params:(NSDictionary *)dic
                 forVC:(JHBaseH5VC *)vc
{
    NSString *host = URL.host;
    
    if ([host isEqualToString:@"refreshComplete"]) { // 停止刷新
        [vc endRefresh];
    }else if ([host isEqualToString:@"refresh"]) { // 刷新某个页面
        NSArray *vcs = vc.navigationController.viewControllers;
        for (JHBaseH5VC *h5vc in vcs) {
            if ([h5vc.identifier isEqualToString:URL.path]) {
                [h5vc beginRefresh];
                break;
            }
        }
    }
}

@end
