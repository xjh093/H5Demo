//
//  JHURLParser+Alert.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/18.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHURLParser+Alert.h"

@implementation JHURLParser (Alert)

// qb://dialog?title=(弹窗的title)&message=(弹窗的message)&ensureStr(确认按键的文字)=xxx&cancelStr(取消按键的文字)=xxx
+ (void)alertWithURL:(NSURL *)URL
              params:(NSDictionary *)dic
               forVC:(JHBaseH5VC *)vc
{
    NSString *title   = dic[@"title"];
    NSString *message = dic[@"message"];
    NSString *sure    = dic[@"ensureStr"]?:@"确认";
    NSString *cancel  = dic[@"cancelStr"]?:@"取消";
    
    UIAlertController
    .jhAlertCtrl(title, message, @(1))
    .jh_addNormalAction(sure,^{
        [self callback:URL response:@"1" forVC:vc];
    })
    .jh_addCancelAction(cancel,^{
        [self callback:URL response:@"0" forVC:vc];
    })
    .jh_show(vc);
    
}



@end
