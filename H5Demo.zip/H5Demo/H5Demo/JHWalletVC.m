//
//  JHWalletVC.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/17.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "JHWalletVC.h"

@interface JHWalletVC ()

@end

@implementation JHWalletVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.frameType = JHWebViewFrameType_Navigation;
    [self updateViewFrame];
    self.url = @"http://www.baidu.com";
    [self loadURL:self.url];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -------------------------------------视图-------------------------------------------

#pragma mark -------------------------------------事件-------------------------------------------

#pragma mark -------------------------------------懒加载-----------------------------------------


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
