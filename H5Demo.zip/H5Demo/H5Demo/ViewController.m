//
//  ViewController.m
//  H5Demo
//
//  Created by xuejinghao on 2018/7/17.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.navigationItem.title = @"H5Demo";
    [self xjh_setupViews];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -------------------------------------视图-------------------------------------------

- (void)xjh_setupViews
{
    // load test.html
    NSString *path = [[NSBundle mainBundle] bundlePath];
    NSURL *baseURL = [NSURL fileURLWithPath:path];
    NSString * htmlPath = [[NSBundle mainBundle] pathForResource:@"home"
                                                          ofType:@"html"];
    NSString * htmlContent = [NSString stringWithContentsOfFile:htmlPath
                                                       encoding:NSUTF8StringEncoding
                                                          error:nil];
    
    [self.webView loadHTMLString:htmlContent baseURL:baseURL];
    self.frameType = JHWebViewFrameType_Navigation;
    self.refreshType = JHRefreshType_Both;
    self.identifier = @"/home";
    [self updateViewFrame];
}

#pragma mark -------------------------------------事件-------------------------------------------

#pragma mark -------------------------------------懒加载-----------------------------------------



@end
